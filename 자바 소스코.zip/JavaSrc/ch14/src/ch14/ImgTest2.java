package ch14;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.font.GraphicAttribute;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.MalformedInputException;

public class ImgTest2 extends Frame{
	Image img;
	public ImgTest2(){
		String str = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Aegithalos_caudatus_front-on_2.jpg/300px-Aegithalos_caudatus_front-on_2.jpg";
		try {
			URL url = new URL(str);
			img = Toolkit.getDefaultToolkit().getImage(url);
		} catch (MalformedURLException e) {
		}
		setSize(1000,1000);
		setVisible(true);
	}
	public void paint(Graphics g) {
		g.drawImage(img,0,0,this);
	}
	
	public static void main(String[] args) {
		new ImgTest2();
	}
}
