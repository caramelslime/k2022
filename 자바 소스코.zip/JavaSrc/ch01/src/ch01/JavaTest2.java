package ch01;
/* 작성자: 김현서 c+s+? 누르면 블록주석
 * 작성일: 2022년 6월 28일
 * 연락처: 010-8838-0247
 */
public class JavaTest2 {
//	대봑이라고 출력할 거얌
	public static void main(String[] args) {
		System.out.println("대봑");
	}

}
