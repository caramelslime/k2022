package ch01;

public class Anyneog {

	public static void main(String[] args) {
		System.out.println("안녕 ! 컴 동지들");
		System.out.println(	"헐~");
		
		
	}

}
