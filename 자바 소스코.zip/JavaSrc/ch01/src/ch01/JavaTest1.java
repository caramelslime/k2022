package ch01;

public class JavaTest1 {

	public static void main(String[] args) {
		System.out.println("대박사건 !!!");
		System.out.println("허걱! 허각!! 허공!! 헐~");
	}

}
