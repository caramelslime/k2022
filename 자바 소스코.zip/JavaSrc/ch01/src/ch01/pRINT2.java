package ch01;

public class pRINT2 {
	public static void main(String[] args) {
		System.out.println(87);
		System.out.println(7.86);
		System.out.println("대박사건");
		System.out.println("8+6="+(8+6));
		System.out.println(3.15+"는 실 수 입니다");
		System.out.println("3 + 5");// 문자열
		System.out.println(3+5);// 얀산
		
	}

}
