package ch01;
/* 작성자: 김현서		API에 반영 안됨
 * 작성일: 2022년 6월 28일
 *  목적: 주석테스트
 */
/** 이 주석은 API문서에 반영, 9장에서 수업
 * 작성자: 김현서
 * 작성일: 2022년 6월 28일
 *  목적: 주석테스트
 */
class comment1 {

	public static void main(String[] args) {
		// 문장출력, 프로그램 설명 한줄설명
		System.out.println("이건뭐야~");
		System.out.println("김건모야~");
/*	c+ /를 누르면 해당하는 범위의 줄이 주석// /*주석시작
		System.out.println("대박사건 !!!");
		System.out.println("허걱! 허각!! 허공!! 헐~");*/ // */주석끝
	}

}
