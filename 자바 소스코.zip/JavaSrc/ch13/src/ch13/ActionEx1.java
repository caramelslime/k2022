package ch13;

import java.awt.Button;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionEx1 extends Frame implements ActionListener {
	Button btn;
	TextArea ta;
	public ActionEx1() {
		btn = new Button("��ư�� Ŭ���ϼ���");
		ta = new TextArea();
		add("North",btn);
		add("Center",ta);
		setSize(300,300);
		setVisible(true);
		btn.addActionListener(this);
	}
	public static void main(String[] args) {
		new ActionEx1();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		ta.append("button click\n");
		
	}
}
