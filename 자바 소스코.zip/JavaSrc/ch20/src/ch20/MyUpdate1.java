package ch20;
import java.sql.*;
import java.util.Scanner;
public class MyUpdate1 {
	public static void main(String[] args) throws SQLException {
		String driver="com.mysql.cj.jdbc.Driver";//--8.0�� mysql
		String url = "jdbc:mysql://127.0.0.1:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc= new Scanner(System.in);
		System.out.println("���� �� ��� �Է�");
		int empno = Integer.parseInt(sc.nextLine());
		System.out.println("������ �̸� �Է�");
		String ename = sc.nextLine();
		System.out.println("������ ���� �Է�");
		String job = sc.nextLine();
		String sql = String.format("update emp set ename=?,job=? where empno = ?");
		int result =0;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"root","mysql");
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(3, empno);
			pstmt.setString(1, ename);
			pstmt.setString(2, job);
			result = pstmt.executeUpdate();
			if(result>0)System.out.println("���� ������");
			else System.out.println("������ ������ ����ü");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			pstmt.close();conn.close();
		}
		sc.close();
	}
}
