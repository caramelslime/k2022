package ch20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class OraDelete1 {
	public static void main(String[] args) throws SQLException {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �μ��ڵ� �Է�");
		int deptno = Integer.parseInt(sc.nextLine());
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = String.format("delete dept where deptno=?", deptno);
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","tiger");
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, deptno);
			int rs = pstmt.executeUpdate();
			if(rs>0)System.out.println("���� �Ϸ�");
			else System.out.println("��������");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			pstmt.close();conn.close();
		}
		sc.close();
	}
}
