package ch20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class OracleInsert2 {
	public static void main(String[] args) throws SQLException {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		Scanner sc = new Scanner(System.in);
		System.out.println("�μ��ڵ��Է�");
		int deptno = Integer.parseInt(sc.nextLine());
		System.out.println("�μ����Է�");
		String dname = sc.nextLine();
		System.out.println("�ٹ����Է�");
		String loc = sc.nextLine();
		
		Connection conn = null;
		Statement stmt = null;
//		String sql = "insert into dept values("+deptno+","+dname+","+loc+")";
//		String sql = String.format("insert into dept values(%d,'%s','%s')", deptno,dname,loc);
		PreparedStatement pstmt =null;//� �����ϱ⽱�ٰ� ���� �غ�� 
		String sql = String.format("insert into dept values(?,?,?)");
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","tiger");
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, deptno);//?ù���� �� �μ���ȣ
			pstmt.setString(2, dname);
			pstmt.setString(3, loc);
			int result = pstmt.executeUpdate();
			if(result>0){System.out.println("�Է¼���");
			
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			pstmt.close();conn.close();
		}
	}
}
