package ch20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MyInsert1 {
	public static void main(String[] args) throws SQLException {
		String driver="com.mysql.cj.jdbc.Driver";//--8.0�� mysql
		String url = "jdbc:mysql://127.0.0.1:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
		Scanner sc = new Scanner(System.in);
		System.out.println(" ��� �Է�");
		int empno = Integer.parseInt(sc.nextLine());
		System.out.println(" �̸� �Է�");
		String ename = sc.nextLine();
		System.out.println(" ���� �Է�");
		String job = sc.nextLine();
		System.out.println(" �޿� �Է�");
		int sal = Integer.parseInt(sc.nextLine());
		System.out.println(" �μ��ڵ� �Է�");
		int deptno = Integer.parseInt(sc.nextLine());
		Connection conn = null;
		Statement stmt =null;
		String sql = String.format("insert into emp (empno,ename,job,sal,deptno)values(%d,'%s','%s',%d,%d)",empno,ename,job,sal,deptno);
		try {
			Class.forName(driver);
			conn= DriverManager.getConnection(url,"root","mysql");
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			if(result>0)System.out.println("�Է¼���");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			stmt.close();conn.close();
		}
	}
}
