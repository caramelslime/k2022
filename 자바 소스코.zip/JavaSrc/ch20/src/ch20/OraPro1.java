package ch20;
import java.sql.*;
import java.util.Scanner;
public class OraPro1 {
	public static void main(String[] args) throws SQLException {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �μ��ڵ�");
		int deptno = Integer.parseInt(sc.nextLine());
		System.out.println("������ �μ���");
		String dname = sc.nextLine();
		System.out.println("������ �ٹ���");
		String loc = sc.nextLine();
		Connection conn = null;
		CallableStatement cstmt= null;
		String sql = "{call update_dept(?,?,?)}";
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","tiger");
			cstmt = conn.prepareCall(sql);
			cstmt.setInt(1, deptno);
			cstmt.setString(2, dname);
			cstmt.setString(3, loc);
			int rs = cstmt.executeUpdate();
			if(rs>0)System.out.println("��������");
			else System.out.println("��������");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			cstmt.close();conn.close();
		}
		sc.close();
	}
}
