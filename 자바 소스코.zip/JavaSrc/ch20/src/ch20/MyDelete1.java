package ch20;
import java.sql.*;
import java.util.Scanner;
public class MyDelete1 {
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("������ ���");
		int empno = sc.nextInt();
		String driver="com.mysql.cj.jdbc.Driver";//--8.0�� mysql
		String url = "jdbc:mysql://127.0.0.1:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
		Connection conn = null;
		Statement stmt = null;
		String sql = String.format("delete from emp where empno=%d", empno);
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"root","mysql");
			stmt = conn.createStatement();
			int rs = stmt.executeUpdate(sql);
			if(rs >0)System.out.println("���� ������");
			else System.out.println("���� ���ϵ�");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			stmt.close();conn.close();
		}
		
		sc.close();
	}
}
