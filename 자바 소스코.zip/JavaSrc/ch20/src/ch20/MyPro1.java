package ch20;
import java.sql.*;
import java.util.Scanner;
public class MyPro1 {
	public static void main(String[] args) throws SQLException {
		String driver="com.mysql.cj.jdbc.Driver";//--8.0�� mysql
		String url = "jdbc:mysql://127.0.0.1:3306/test?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
		Scanner sc = new Scanner(System.in);
		System.out.println("�Է��� �μ��ڵ�");
		int deptno = Integer.parseInt(sc.nextLine());
		System.out.println("�Է��� �μ���");
		String dname = sc.nextLine();
		System.out.println("�Է��� �ٹ���");
		String loc = sc.nextLine();
		Connection conn = null;
		CallableStatement cstmt= null;
		String sql = "{call dept_insert(?,?,?)}";
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"root","mysql");
			cstmt = conn.prepareCall(sql);
			cstmt.setInt(1, deptno);
			cstmt.setString(2, dname);
			cstmt.setString(3, loc);
			int rs = cstmt.executeUpdate();
			if(rs>0)System.out.println("�Է¼���");
			else System.out.println("������");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			cstmt.close();conn.close();
		}
		sc.close();
	}
}
