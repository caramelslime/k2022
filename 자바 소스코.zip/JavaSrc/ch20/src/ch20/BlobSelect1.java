package ch20;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BlobSelect1 {
	public static void main(String[] args) throws SQLException {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		String sql = "select photo from test where id='a1'";
		Connection conn = null; PreparedStatement pstmt = null; ResultSet rs = null;
		try {
			File file =new File("kk.jpg");
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","tiger");
			pstmt = conn.prepareStatement(sql);
			 rs = pstmt.executeQuery();
			if(rs.next()) {
				Blob blob = rs.getBlob("photo");
				InputStream is =blob.getBinaryStream();
				FileOutputStream fos =new FileOutputStream(file);
				byte[] buffer = new byte[1024];
				int i=0;
				while((i=is.read(buffer))!=-1) {
					fos.write(buffer,0,i);
				}
				is.close();fos.close();
				System.out.println("�׸����� ��¼���");
			}else System.out.println("����");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			rs.close();pstmt.close();conn.close();
		}
	}
}
