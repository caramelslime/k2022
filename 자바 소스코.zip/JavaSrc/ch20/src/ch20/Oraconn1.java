package ch20;

import java.sql.Connection;
import java.sql.DriverManager;

public class Oraconn1 {
	public static void main(String[] args) {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		
		
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url,"scott","tiger");
			System.out.println("���� ������");
			conn.close();
		} catch (Exception e) {
			System.out.println("�����غη���"+e.getMessage());
		}
	}
}
