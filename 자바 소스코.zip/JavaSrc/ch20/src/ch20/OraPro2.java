package ch20;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class OraPro2 {
	public static void main(String[] args) throws SQLException {
		String driver = "oracle.jdbc.OracleDriver";//������
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		Scanner sc = new Scanner(System.in);
		System.out.println("�˻��� ���");
		int empno = Integer.parseInt(sc.nextLine());
		Connection conn = null;
		CallableStatement cstmt= null;
		String sql = "{call emp_into(?,?,?)}";
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,"scott","tiger");
			cstmt = conn.prepareCall(sql);
			cstmt.setInt(1, empno);
			cstmt.registerOutParameter(2, Types.VARCHAR);
			cstmt.registerOutParameter(3, Types.INTEGER);			
			cstmt.execute();
			System.out.println("�̸�:"+cstmt.getString(2));
			System.out.println("�̸�:"+cstmt.getInt(3));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			cstmt.close();conn.close();
		}
		sc.close();
	}
}
