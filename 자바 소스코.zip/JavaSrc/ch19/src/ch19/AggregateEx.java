package ch19;

import java.util.Arrays;
import java.util.Comparator;
import java.util.OptionalDouble;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class AggregateEx {
	public static void main(String[] args) {
		long count = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).count();
		System.out.println("¦������: "+count);
		long sum = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).sum();
		System.out.println("¦����: "+sum);
//		OptionalDouble avg = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).average();
		double avg = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).average().getAsDouble();
		System.out.println("¦�����: "+avg);
		int max = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).max().getAsInt();
		System.out.println("¦���ִ�: "+max);
		int min = Arrays.stream(new int[] {1,2,3,4,5}).filter(n->n%2==0).min().getAsInt();
		System.out.println("¦���ּ�: "+min);
		int first = Arrays.stream(new int[] {1,21,3,4,5}).sorted().filter(n->n%3==0).findFirst().getAsInt();
		System.out.println("3�ǹ�� ù����: "+first);
		
	}
}
