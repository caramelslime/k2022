package ch19;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class SortingEx1 {
	public static void main(String[] args) {
		IntStream intstream = Arrays.stream(new int[] {5,2,4,3,1});
		intstream.sorted().forEach(n->System.out.println(n+","));
		List<Student2> list =Arrays.asList(new Student2("����",77),new Student2("����",47),new Student2("�ϴ�",87),new Student2("����",99));
		list.stream().sorted().forEach(s->System.out.println(s.getScore()));
		list.stream().sorted(Comparator.reverseOrder()).forEach(s->System.out.println(s.getScore()));
	}
}

