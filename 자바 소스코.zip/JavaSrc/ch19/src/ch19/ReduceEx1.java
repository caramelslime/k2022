package ch19;

import java.util.Arrays;
import java.util.List;

public class ReduceEx1 {
	public static void main(String[] args) {
		List<Student2> slist= Arrays.asList(new Student2("jenny",51),new Student2("nunu",71),new Student2("bonuy",21));
		int sum1 = slist.stream().mapToInt(Student2::getScore).sum();
		int sum2 = slist.stream().map(Student2::getScore).reduce((a,b)->a+b).get();
//																�ʱⰪ						
		int sum3 = slist.stream().map(Student2::getScore).reduce(0,(a,b)->a+b);
		System.out.println("����:"+sum1);
		System.out.println("����:"+sum2);
		System.out.println("����:"+sum3);
	}
}
