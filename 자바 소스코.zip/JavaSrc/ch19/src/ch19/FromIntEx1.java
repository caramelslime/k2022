package ch19;

import java.util.stream.IntStream;

public class FromIntEx1 {
	static int sum =0;
	public static void main(String[] args) {
		IntStream stream = IntStream.range(1, 101);//1~100����
		stream.forEach(a-> sum+=a );
		System.out.println("�հ�:"+sum);
	}
}
