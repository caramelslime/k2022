package ch19;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import ch19.Student3.City;

public class GroupByEx {
	public static void main(String[] args) {
		List<Student3> list = Arrays.asList(new Student3("����", 88, Student3.Gender.FEMALE,City.Seoul),
				new Student3("����", 77, Student3.Gender.MALE,City.Seoul),
				new Student3("����", 99, Student3.Gender.FEMALE,City.Busan),
				new Student3("����", 66, Student3.Gender.MALE,City.Busan));
		
		Map<Student3.Gender,List<Student3> > mapByGender= list.stream().collect(Collectors.groupingBy(Student3::getGender));
		System.out.print("����:");
		mapByGender.get(Student3.Gender.MALE).stream().forEach(s->System.out.print(s.getName()+" "));
		System.out.println();
		System.out.print("����:");
		mapByGender.get(Student3.Gender.FEMALE).stream().forEach(s->System.out.print(s.getName()+" "));
		System.out.println();
		Map<Student3.City, List<Student3>> mapByCity = list.stream().collect(Collectors.groupingBy(Student3::getCity));
		System.out.print("����:");
		mapByCity.get(Student3.City.Seoul).stream().forEach(s->System.out.print(s.getName()+" "));
		System.out.println();
		System.out.print("�׻�:");
		mapByCity.get(Student3.City.Busan).stream().forEach(s->System.out.print(s.getName()+" "));
		
	}
}
