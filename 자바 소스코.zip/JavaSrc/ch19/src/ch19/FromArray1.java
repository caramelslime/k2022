package ch19;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class FromArray1 {
	public static void main(String[] args) {
		String[] list = {"����","����"};
		Stream<String> strStream = Arrays.stream(list);
		strStream.forEach(a-> System.out.print(a+","));
		System.out.println("========");
		List<Student1> ist = Arrays.asList(new Student1("����", 24),new Student1("����", 42));
		Stream<Student1> strs = ist.stream();
		strs.forEach(a->System.out.println(a.getName()+","));
		System.out.println("==========");
		strs = ist.stream();
		strs.forEach(n->System.out.println(n.getAge()+","));
		
	}
}
