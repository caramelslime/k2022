package ch10;

public class MyException2 extends Exception{
	private static final long serialVersionUID = 1L;
	public MyException2(String msg) {
		super(msg);
	}
	

}
