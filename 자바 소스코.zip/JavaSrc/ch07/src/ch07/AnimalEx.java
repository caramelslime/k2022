package ch07;

public class AnimalEx {
	public static void main(String[] args) {
		Animal[] animals = new Animal[3];
		animals[0] = new Bird();
		animals[1] = new Pig();
		animals[2] = new Fish();
//		Animal bird = new Bird();
//		Animal pig = new Pig();
//		Animal fish = new Fish();
//		Animal[] animals = {bird,pig,fish};
		for(int i= 0;i<animals.length;i++) {
			animals[i].move();//자식메서드
			System.out.println(animals[i].x);//부모변수
			if(animals[i] instanceof Bird)
				((Bird)animals[i]).eat();
		}
		System.out.println("=====================");

		for(Animal anima : animals) {
			anima.move();
			System.out.println(anima.x);
			if(anima instanceof Bird)
				((Bird)anima).eat();
		}
	}
}
