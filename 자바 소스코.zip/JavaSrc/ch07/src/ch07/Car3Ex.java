package ch07;

public class Car3Ex {
	public static void main(String[] args) {
//		FireEngine3 fe = new Car3(); 자식을 생성하고 부모생성 불가 down casting 강제 형변환필요
		Car3 car1 = new FireEngine3();//부모 선언후 자식생성 가능 up casting 묵시적
		Car3 car2 = new Ambulance3();//부모 선언후 자식생성 가능 up casting 묵시적
		Car3 car3 = new Bus3();//부모 선언후 자식생성 가능 up casting 묵시적
		//부모를 선언하고 자식대입이면 부모에있는 메서드만 사용가능하다.
		car1.drive();car2.drive();car3.drive();//car1.fire();
		System.out.println("============");
		Car3[] cars = {car1,car2 ,car3};//부모클래스의 배열형식으로 처리가능
		for(Car3 car :cars) {
			car.drive();
		}
		System.out.println("=====================");
		for(int i=0 ;i<cars.length;i++) {
			cars[i].drive();//실행되는 것은 자식메서드지만 부모메서드와 이름이 같은거만 실ㄹ행가능
			System.out.println("color="+cars[i].color);//변수는 부모것만 실행
			if(cars[i] instanceof FireEngine3) {// 파이어엔진에서만 생성된것만
			((FireEngine3)cars[i]).fire();}//다운캐ㅡ팅
		}
	}
}
