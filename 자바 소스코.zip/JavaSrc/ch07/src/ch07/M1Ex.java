package ch07;

public class M1Ex {
	public static void main(String[] args) {
		M2 h = new M2(52,14,234);
		M1 h1 = new M1(24,124);
		 h1.prn();
		 h.prn();
	}
}
