package ch07;

class Parent {
	 int x=100;
	 Parent() { 
	 this(200); // Parent(int x)를 호출
	 }
	 Parent(int x) { this.x = x; }
	 int getX() { return x; }
	}
	class Child extends Parent {
	 int x = 3000;
	 Child() {
	 this(1000); // Child(int x)를 호출
	 }
	 Child(int x) { this.x = x; }//매개변수없는 패런트 호출
	}
	class Exercise7_7 {
	 public static void main(String[] args) {
	 Child c = new Child();//매개변수 없는 child로
	 System.out.println("x="+c.getX());
	 }
	}