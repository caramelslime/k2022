package ch07;

public class C2 extends C1{//C1이 생성됭야한다.
	int c2= 100;
	C2(){
		System.out.println("아버지 생성자");
	}
	void c21() {
		System.out.println("난 아버지 메서드");
	}
}
class C3 extends C2{//C2가 생성되어야한다
	C3(){
		System.out.println("자식 생성자");
	}
	void c31() {
		System.out.println("난 자식 메서드");
	}
}