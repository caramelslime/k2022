package ch07;

public class FruitBuyer3 {
	String name;
	int numOfApple ;
	int money ;
	public FruitBuyer3(String name,int numOfApple , int money) {
		this.name = name;this.numOfApple=numOfApple;this.money=money;
	}
	//				선언 :판매자가 여러명 가능
	void buyApple(FruitSeller3 fs1 ,int amt) {//amt 사과 구매할돈
		
	
		if(money<amt) {			System.out.println(name+"는 돈이없당");
		System.out.println("=====================");

		}
		else {
			int num = fs1.saleApple(amt);
			if(num>0) {//판매자가 사과가 있어서 산경우
				
				numOfApple +=num;
				money -= (amt-amt%fs1.PRICE_PER_APPLE);
				System.out.printf("%s %d개 구매 %d원 사용\n",name,num,amt-amt%fs1.PRICE_PER_APPLE);
				System.out.println("=====================");
}
			else {System.out.println(name+"는 사과를 못샀읍니다");//판매자가 사과가 없다
			System.out.println("=====================");
			}
		}
		
	}
	void print() {
		System.out.println(name+"의 사과 갯수:"+numOfApple);
		System.out.println(name+"의 현금 잔액:"+money);
		System.out.println("=============");
		
	}
}
