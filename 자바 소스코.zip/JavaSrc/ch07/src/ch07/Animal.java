package ch07;

public class Animal {
	int x= 8;
	void move() {
		System.out.println("무빙한다");
	}
}
class Bird extends Animal{
	void move() {
		System.out.println("날라다닌다");
	}
	void eat() {
		System.out.println("부리로 쪼아먹는다");
	}
}
class Pig extends Animal{
	int x =66;
	void move() {
		System.out.println("기어댕긴다");
	}
}
class Fish extends Animal{
	void move() {
		int x =55;
		System.out.println("헤엄친다");
	}
}
