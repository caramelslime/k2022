package ch07;

public class Engine {
	private int dip;
	private String tp;
	
	public Engine() {
}
	public Engine(int dip,String tp) {
		this.dip=dip;this.tp=tp;
	}
	public int getDip() {
		return dip;
	}
	public void setDip(int dip) {
		this.dip = dip;
	}
	public String getTp() {
		return tp;
	}
	public void setTp(String tp) {
		this.tp = tp;
	}
	void prn() {
		System.out.println("=============");
		System.out.println("배기량: "+dip);
		System.out.println("엔진타입: "+tp);
	}
}
