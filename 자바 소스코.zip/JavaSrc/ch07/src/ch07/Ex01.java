package ch07;
class Product{
	int price;
	int bonuspoint;
//	Product(){}
	Product(int price){
		this.price=price;
		bonuspoint = (int)(price/10.0);
	}
}
class Tv extends Product{
	Tv(){//상속받으면 무조건 부모생성
		super(199);
	}
	public String toString() {
		return "Tv";
		
	}
}
public class Ex01 {
	public static void main(String[] args) {
		
	
	Tv tv = new Tv();

	}
}
