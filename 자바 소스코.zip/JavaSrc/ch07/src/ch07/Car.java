package ch07;

public class Car {
	private Engine eg;//클래스 안에 클래스 포함관계 has-a
	private String color;
	Car(){
	}
	Car(Engine eg, String color){
		this.eg=eg; this.color=color;
	}
	public Engine getEg() {
		return eg;
	}
	public void setEg(Engine eg) {
		this.eg = eg;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	void prnCar() {
		eg.prn();
		System.out.println("색깔: "+color);
	}
}
