package ch07;
class A {
	int a=10;
	void m1() {
		System.out.println("난 부모 멧소드");
	}
	
}
class A1 extends A{//A의 멤버 변수와 메소드를 재사용효과
	int a1 =12;
	void m2() {
		System.out.println("난 자식 메서드");
	}
}
public class Inher1 {
	public static void main(String[] args) {
		A a = new A(); a.m1(); System.out.println("a.a="+a.a);
		A1 a1 = new A1(); a1.m1();a1.m2();System.out.println("a1.a="+a.a);
	}
}
