package ch07;
class D1{
	String st1 = "허걱";
	D1(){
		System.out.println("I'm boss");
	}
	void m1(){
		System.out.println("I'm first method");
	}
}
class D2 extends D1{
	String st2 = "허공";
	D2(){
		System.out.println("I'm no2");
	}
	void m2(){
		System.out.println("I'm second method");
	}
}
class D3 extends D2{
	String st3 = "헐";
	D3(){
		System.out.println("I'm no3");
	}
	void m3(){
		System.out.println("I'm last method");
	}
}
public class Inher4 {
	public static void main(String[] args) {
		D3 d3 =new D3();
		System.out.println("st1:"+d3.st1);
		System.out.println("st2:"+d3.st2);
		System.out.println("st3:"+d3.st3);
		d3.m1();d3.m2();d3.m3();
	}
}
