package ch07;
import pac.One;
public class OneEx extends One{
	public static void main(String[] args) {
		OneEx one = new OneEx();
		one.getOne();
		System.out.println(one.getOne());
	}
}
