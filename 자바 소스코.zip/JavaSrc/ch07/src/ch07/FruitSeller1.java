package ch07;

public class FruitSeller1 {
	int numOfApple =20;
	int money =0;
	final int PRICE_PER_APPLE = 1500;
	int saleApple(int amt) {//사과 사는사람한테 받은돈
		money +=(amt-amt%PRICE_PER_APPLE);//받은돈에서 거스름돈 뺴기
		int num =amt/PRICE_PER_APPLE;
		numOfApple -=num;
		return num;
		
		
	}
	void print() {
		System.out.println("판매자 사과 갯수:"+numOfApple);
		System.out.println("판매자의 현금 잔액:"+money);
		System.out.println("=====================");
	}
}
