package ch07;
class E1{
	int k1 = 7;
//	E1(){
//		System.out.println("매개변수 없는 생성자");
//	}//super 없으면 디폴트 생성자 만들어야함
	E1(String str){
//		this();
		System.out.println("매개변수하나:"+str);
	}
}
class E2 extends E1{
	E2(){//super로 매개변수 있는 생성자 소환
		super ("너야"); //이게없으면 매개변수 없는 생성자 (default)생성자가 실행되는데 디폴트가 없으면 오류
		System.out.println("매개변수 없는 자식");
	}
}
public class Super1 {
	public static void main(String[] args) {
		E2 e2 = new E2();
		System.out.println("k1= "+e2.k1);
	}
}
