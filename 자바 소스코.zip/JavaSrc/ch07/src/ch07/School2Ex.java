package ch07;

public class School2Ex {
	public static void main(String[] args) {
		Person2[] persons = new Person2[6];
		persons[0] = new Student2("뷔",25,"1반");
		persons[1] = new Student2("로제",26,"1반");
		persons[2] = new Teacher2("유재석",45,"자바");
		persons[3] = new Teacher2("정준하",55,"JSP");
		persons[4] = new Manager2("박보검",35,"화장실 청소");
		persons[5] = new Manager2("제니",22,"노래");
		for(Person2 person : persons) {
			person.prn();
			if(person instanceof Manager2) {
				((Manager2)person).disp();
				}
		}
	}
}
