package ch07;

public class PersonEx {
	public static void main(String[] args) {
		Student st1 = new Student("로제",24,"3반");
		Student st2 = new Student("보검",25,"1반");
		Teacher t = new Teacher("이준호",51,"자바");
		Manager m = new Manager("제니",24,"화장실 청소");
		
		st1.prnSt();st2.prnSt();t.prnT();m.prnM();
	}
}
