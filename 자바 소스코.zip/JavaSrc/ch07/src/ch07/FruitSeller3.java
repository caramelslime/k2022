package ch07;

public class FruitSeller3 {
	String name;
	int numOfApple ;
	int money;
	final int PRICE_PER_APPLE = 1500;
	public FruitSeller3(String name,int numOfApple , int money) {
		this.name = name;this.numOfApple=numOfApple;this.money=money;
	}
	int saleApple(int amt) {//사과 사는사람한테 받은돈
		int num =amt/PRICE_PER_APPLE;
		if (numOfApple>=num) {
			
			money +=(amt-amt%PRICE_PER_APPLE);//받은돈에서 거스름돈 뺴기
			numOfApple -=num;
			System.out.printf("%s %d개 판매, 수입 %d원\n",name,num,(amt-amt%PRICE_PER_APPLE));
		}
		else {
			System.out.println(name+"의 사과가 부족해서 팔수가 없읍니다");
			num=0; //안판거
		}
		return num;
		
		
	}
	void print() {
		System.out.println(name+"의 사과 갯수:"+numOfApple);
		System.out.println(name+"의 현금 잔액:"+money);
		System.out.println("=====================");
	}
}
