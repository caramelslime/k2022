package ch07;

public class C1 {
	private String c1="대박";
	C1(){
		System.out.println("할아버지 생성자");
	}
	void c11() {
		System.out.println("난 할아버지 메서드");
	}
	String getC1() {
		return c1;
	}
	
}
