package ch07;

public class M1 {
	int x;
	M1(int x ){
		this.x=x;//제일먼저실행
		System.out.println("부모생성자 매개변수 1개"+x);
		
	}
	M1(int x , int y){
		this(x);//매개변수 1개 M1으로
		System.out.println("x = " +x);
	}
	void prn() {
		System.out.println("x아아 = "+x);
	}
	
}
class M2 extends M1{
	M2(int x, int y){
		super(x,y);//매개변수 2개 M1으ㅗ
		System.out.println("자식 생성자 매개변수 2개");
	}
	M2 (int x, int y ,int z){
		this(x,y);//M2(x,y)로
		System.out.println("매개변수: 3개");
	}
}
