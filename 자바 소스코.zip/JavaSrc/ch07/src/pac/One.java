package pac;

public class One {
	public String one;
	protected String getOne() {
		return one;
	}
}
