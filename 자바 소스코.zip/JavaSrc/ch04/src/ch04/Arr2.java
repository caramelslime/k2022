package ch04;

public class Arr2 {
	public static void main(String[] args) {
		int[] a= new int[5];
		for(int i=0;i<=a.length;i++) {
			a[i]= (int) (Math.random()*10+1);

			System.out.println("a["+i+"]="+a[i]);
		}
		System.out.println("==========");
		for(int i : a) {
			System.out.println(i);
		}
	}
}
