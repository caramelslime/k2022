package ch04;

public class Ex2 {

	public static void main(String[] args) {
		int[][]arr= {{5,5,5,5,5},{10,10,10,10,10},
					{20,20,20,20,20},{30,30,30,30,30}};
		int sum=0;
		int[]tot= new int [arr[0].length];
		for(int i =0;i<arr.length;i++) {
			for(int j = 0;j<arr[i].length;j++) {
				sum+=arr[i][j];
				tot[j]+=arr[i][j];
			}
		}
		System.out.println(sum);
		for(int j =0 ;j<tot.length;j++)
			System.out.print(tot[j]+"\t");
		
	}

}
