package ch04;

public class SecArr3 {

	public static void main(String[] args) {
		int[][] score= {{90,88,78,},{77,88,99},{55,99,95},{78,90,67},{99,66,88}};
		String[] name = {"jenny","bogum","rose","eunwoo","suzy"};
		int sum=0;
		System.out.println("이름\t국어\t영어\t수학\t총점");
		System.out.println("========================");
		for(int i=0; i<score.length;i++) {
			System.out.print(name[i]+"\t");
			for(int j=0;j<score[i].length;j++) {
				System.out.print(score[i][j]+"\t");
				sum+=score[i][j];
			}
		System.out.printf("총합은 %d 평균은 %.2f\n",sum,(float)sum/score[i].length);
		sum=0;
		}
		System.out.println("========================");

//		for(int[] t : score) {
//			for(String k:name) {
//			System.out.print(k+"\t");
//				for(int t1: t) {
//					System.out.print(t1+"\t");
//					sum+=t1;
//				}
//				System.out.println(sum);
//				sum=0;
//				}
//}

		
		}
}
