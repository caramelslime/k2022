package ch04;

public class Ex4 {

	public static void main(String[] args) {
		int []unit= {50000,10000,5000,1000};
		int money = 372000;
		
		for(int i =0;i<unit.length;i++) {
		System.out.println(unit[i] + "원 : " + money/unit[i]);
		money = money%unit[i];
		}
	}

}
