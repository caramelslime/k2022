package ch04;

public class Score2 {

	public static void main(String[] args) {
		String subject = "매출현황";
		String [] product = { "냉장고","티비","청소기"};
		String [] month = {"jan","feb","mar","apr",};
		int [][] earn = {{250,170,300,780},{170,120,150,220},{450,230,400,250}};
		int []tot= new int [ earn[0].length];
		
		int len = 44, sum =0;
		System.out.println(subject);
		System.out.println("=============");
		System.out.print("제품명\t");// hard coding  추천하지않음
		for(int i =0;i<month.length;i++) {
			System.out.print(month[i]+"\t");
			
		}
		System.out.print("합계\t평균");
		System.out.println();
		for(int i =0 ;i<len;i++) {
			System.out.printf("=");
		}
		System.out.println();
		for(int i = 0 ; i<earn.length;i++) {
			System.out.print(product[i]+"\t");
			for(int j = 0 ; j<earn[i].length;j++){
				System.out.print(earn[i][j]+"\t");
				sum+=earn[i][j];
				tot[j]+=earn[i][j];//열합
			}
			System.out.printf("%d\t%.1f\n",sum,(double)sum/earn[i].length);
			sum = 0;
			
			}
		for(int i =0 ;i<len;i++) {
			System.out.printf("=");
		}
		System.out.println();
		System.out.print("total\t");
		for(int i = 0 ;i<tot.length;i++) {
			System.out.print(tot[i]+"\t");
			sum+=tot[i];
		}
		System.out.printf("%d\t%.1f\n",sum,(double)sum/tot.length);
	
	}
}
