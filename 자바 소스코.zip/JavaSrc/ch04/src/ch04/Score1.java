package ch04;

public class Score1 {

	public static void main(String[] args) {
		String title = "SCORE";
		String [] name = { "BTS","IU","MC YOO","BLAC_Pn"};
		String [] tile = {"name","kor","eng","math","total","avg"};
		int [][] score = {{90,80,70},{76,86,90},{97,78,80},{82,98,78}};
		int []tot= new int [ score[0].length];
		
		int len = 44, sum =0;
		System.out.println(title);
		System.out.println("=============");
		for(int i =0;i<tile.length;i++) {
			System.out.println(tile[i]+"\t");
			
		}
		System.out.println();
		for(int i =0 ;i<len;i++) {
			System.out.printf("=");
		}
		System.out.println();
		for(int i = 0 ; i<score.length;i++) {
			System.out.print(name[i]+"\t");
			for(int j = 0 ; j<score[i].length;j++){
				System.out.print(score[i][j]+"\t");
				sum+=score[i][j];
				tot[j]+=score[i][j];//열합
			}
			System.out.printf("%d\t%.1f\n",sum,(double)sum/score[i].length);
			sum = 0;
			
			}
		for(int i =0 ;i<len;i++) {
			System.out.printf("=");
		}
		System.out.println();
		System.out.print("total\t");
		for(int i = 0 ;i<tot.length;i++) {
			System.out.print(tot[i]+"\t");
			sum+=tot[i];
		}
		System.out.printf("%d\t%.1f\n",sum,(double)sum/tot.length);
	
	}
}
