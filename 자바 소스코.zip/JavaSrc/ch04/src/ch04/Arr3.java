package ch04;

public class Arr3 {
	public static void main(String[] args) {
		int [] i = {10,20,30,40};
		for(int i1 =0;i1<i.length;i1++)
			System.out.println(i[i1]);
		int[]i2 = new int[] {11,23,123,1233};
		for(int j=0;j<i2.length; j++)
			System.out.println(i2[j]);
		int[]i3;
		i3= new int[] {12,32,42,424};
		for(int a: i3)
			System.out.println(a);
//		int[] i4;
//		i4= {234,423,432,432,523}; 이건 에러
	}
}
