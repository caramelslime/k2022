package ch04;

public class Ex3 {

	public static void main(String[] args) {
		int []coinUnit= {500,100,50,10};
		int money = 2680;
		
		for(int i =0;i<coinUnit.length;i++) {
		System.out.println(coinUnit[i] + "원 : " + money/coinUnit[i]);
		money = money%coinUnit[i];
		}
	}

}
