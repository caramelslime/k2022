package ch04;

import java.util.Arrays;

public class Ex02 {
	public static void main(String[] args) {
		int[] a= new int[]{76,45,34,89,100,50,90,92};
		int temp=0;
		System.out.println("처음:"+Arrays.toString(a));
		for(int i=0;i<=a.length-1;i++) {
			for(int j = i+1 ;j<=a.length-1;j++ )
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			System.out.println(i+1+"회 i실행 후:"+Arrays.toString(a));
		}
		for(int i : a)
			System.out.println(i);
	}
}
