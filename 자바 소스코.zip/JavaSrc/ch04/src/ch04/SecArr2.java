package ch04;

public class SecArr2 {

	public static void main(String[] args) {
		int[][] score= {{90,88,78,},{77,88,99},{55,99,95},{78,90,67}};
		String[] name = {"jenny","bogum","rose","eunwoo"};
		int sum=0;
		System.out.println("이름\t국어\t영어\t수학\t총점");
		for(int i=0; i<score.length;i++) {
			System.out.print(name[i]+"\t");
			for(int j=0;j<score[i].length;j++) {
				System.out.print(score[i][j]+"\t");
				sum+=score[i][j];
			}
		System.out.println(sum);
		sum=0;
		}
		System.out.println("===========");
//		for(int[] t : score) {
//			for(int t1: t) {
//				System.out.print(t1+"\t");
//				sum+=t1;
//			}
//		System.out.println(sum);
//		sum=0;}
	}

}
