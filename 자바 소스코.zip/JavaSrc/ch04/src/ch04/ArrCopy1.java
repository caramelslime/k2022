package ch04;

import java.util.Arrays;

public class ArrCopy1 {

	public static void main(String[] args) {
		int[] arr1 = {12,53,532,5235};
		int[] arr2 = arr1;//주소복사
		int[] arr3 = new int[arr1.length];
		int[] arr4 = new int[arr1.length];
//						값 		원본복사시작위치 대상 대상의복사위치 갯수
		System.arraycopy(arr1, 0, arr4,0, arr1.length);
		for(int i = 0; i<arr2.length;i++)
			arr3[i]= arr1[i];//값 복사
		arr1[1]=100;//2번째 수 변경
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		System.out.println(Arrays.toString(arr3));
		System.out.println(Arrays.toString(arr4));
	}

}
