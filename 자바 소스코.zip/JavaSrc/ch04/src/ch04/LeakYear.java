package ch04;

import java.util.Scanner;

public class LeakYear {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int year;
		
//		do {
//			System.out.println("연도입력:");
//			year=sc.nextInt();
//			if(year%4==0 && year!=100||year%400==0 )
//				System.out.println("윤년");
//			else
//				System.out.println("평년");
//		} while (year != 0);
		while(true) {
			System.out.println("연도 입력:");
			year=sc.nextInt();
			if(year==0) break;
			if(year%4==0 && year!=100||year%400==0 )
				System.out.println("윤년");
			else
				System.out.println("평년");
		}
		System.out.println("program over");
		sc.close();
		
	}

}
