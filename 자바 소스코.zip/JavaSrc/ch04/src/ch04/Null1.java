package ch04;

public class Null1 {

	public static void main(String[] args) {
		int i1=0;
		System.out.println("i1="+i1);
	}

}
