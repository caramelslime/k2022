package ch04;

public class Args1 {
	public static void main(String[] args) {
		for(int i=0; i<args.length;i++)
			System.out.println(args[i]);
		for(String str : args)//확장
			System.out.println(str);
			
	}
}
