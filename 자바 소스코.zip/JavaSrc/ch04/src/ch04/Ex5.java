package ch04;

public class Ex5 {

	public static void main(String[] args) {
		int[][] score= {{67,78,98},{78,98,65},{78,56,90}};
		String[] title= {"국어","영어","수학","합계","최대","최소"};
		int len = 45,sum = 0, max=0,min=100,tot=0,tmax=0,tmin=100;
		
		for(int i = 0 ; i<title.length;i++) {
			System.out.print(title[i]+"\t");
		}
		System.out.println();
		for(int i = 0 ; i<len ; i++)
			System.out.print("=");
		System.out.println();
		for(int i = 0 ; i<len ; i++)
			System.out.print("=");
		System.out.println();
	
		for(int i = 0 ; i<score.length;i++) {
			for(int j=0;j<score[i].length;j++) {
				System.out.print(score[i][j]+"\t");
				sum+=score[i][j];
				if(score[i][j]>max)
					max=score[i][j];
				if(score[i][j]<min)
					min=score[i][j];	
			}
			System.out.printf("국영수 합계:%d 국영수 최고점:%d 최저점:%d \n",sum,max,min);
			tot+=sum;
			if(max>tmax)
				tmax=max;
			if(min<tmin)
				tmin=min;
			sum=0;
			max=0;
			min=100;
		}
		System.out.printf("총합계:%d 전체에서 최고점:%d 최저점:%d \n",tot,tmax,tmin);
	}
}
