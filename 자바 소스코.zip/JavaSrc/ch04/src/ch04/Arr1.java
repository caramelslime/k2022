package ch04;

public class Arr1 {
	public static void main(String[] args) {
		int[] a = new int [5];
		a[0]=45;
		a[1]=22;
		a[2]=43;
		a[3]=44;
		a[4]=65;
		for(int i = 0;i<=a.length;i++)
		System.out.println(a[i]);
// 확장 for, 신 for
		for(int i : a) {
			System.out.println(a);
		}
	}
}
