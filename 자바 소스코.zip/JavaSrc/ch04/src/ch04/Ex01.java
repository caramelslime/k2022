package ch04;

public class Ex01 {

	public static void main(String[] args) {
		int [] a = {76,45,34,89,100,50,90,92};
		int sum=0,max=a[0],min=a[0];
		for(int i : a) {
			sum+= i;
		}
		for(int i =0; i<a.length;i++) {
			if(a[i]>max) max= a[i];
			if(a[i]<min) min= a[i];
			
		}
		System.out.printf("총합은%d 최댓값은%d 최솟값은 %d\n",sum,max,min);
	}

}
