package ch04;

public class VariableArr {
	public static void main(String[] args) {
		int [][] score = new int [3][];
		score[0]=new int[2];
		score[1]=new int[5];
		score[2]=new int[3];
		for(int i = 0 ; i< score.length;i++) {
			for(int j = 0 ; j<score[i].length;j++)
				score[i][j]=(int)(Math.random()*45+1);//1~45 사이의 숫자
		}
		for(int[]k:score) {
			for(int sc: k)
				System.out.print(sc+"\t");
			System.out.println();
		}
	}
	
}
