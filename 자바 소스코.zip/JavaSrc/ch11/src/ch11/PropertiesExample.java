package ch11;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertiesExample {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Properties pts = new Properties();
		String path = 
				PropertiesExample.class.getResource("database.properties").getPath();
		
		pts.load(new FileReader(path));
		System.out.println("driver = "+pts.getProperty("driver"));
		System.out.println("url = "+pts.getProperty("url"));
		System.out.println("username = "+pts.getProperty("username"));
		System.out.println("password = "+pts.getProperty("password"));
		
	}
}
