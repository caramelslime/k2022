package ch11;

public interface Car {
	void print();
}
class Bus implements Car{

	@Override
	public void print() {
		System.out.println("I'm bus");
		
	}
	void move() {
		System.out.println("�°� 40�� �¿���ٴ�");
	}

}
class Taxi implements Car{

	@Override
	public void print() {
		System.out.println("���ýþ�");
	}
	
}
class FireEngine implements Car{

	@Override
	public void print() {
		System.out.println("�� �ҹ���");
	}
	
}
class Ambulance {
	public void print() {
		System.out.println("��������");
	}
}