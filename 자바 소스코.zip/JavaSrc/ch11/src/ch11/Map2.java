package ch11;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Map2 {
	public static void main(String[] args) {
		HashMap<String, String> fruits = new HashMap<>();
		fruits.put("����", "�����ϴ�");
		fruits.put("����", "�ÿ��ϴ�");
		fruits.put("Ű��", "��ŭ�ϴ�");
		Set<String> keys = fruits.keySet();
		for(String key : keys) {
			System.out.println(key+":"+fruits.get(key));
		}
		System.out.println("=======================");
		Iterator<String> its = fruits.keySet().iterator();
		while(its.hasNext()) {
			String key = its.next();
			System.out.println(key+":"+fruits.get(key));
		}
	}
}
