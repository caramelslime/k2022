package ch11;

import java.util.Stack;

public class Stack1 {
	public static void main(String[] args) {
		String[] nations = { "�̱�", "�߱�", "�ѱ�", "����", "�߱�", "�̳k" };
		Stack<String> st = new Stack<>();
		for (String nation : nations) {
			st.push(nation);
		}
		while (!st.empty()) {
			System.out.println(st.pop());
		}
	}
}
