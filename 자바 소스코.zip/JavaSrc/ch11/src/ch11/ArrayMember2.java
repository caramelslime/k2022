package ch11;

import java.util.Arrays;
import java.util.Collections;

public class ArrayMember2 {
	public static void main(String[] args) {
		Member2 m1 = new Member2("����", 21);
		Member2 m2 = new Member2("����", 30);
		Member2 m3 = new Member2("����", 24);
		Member2 m4 = new Member2("����", 27);
		Member2 m5 = new Member2("�缮", 43);
		Member2 m6 = new Member2("��ȣ", 24);
		Member2[] ms = {m1,m2,m3,m4,m5,m6};
		System.out.println(Arrays.toString(ms));
		Arrays.sort(ms);
		System.out.println(Arrays.toString(ms));
		Arrays.sort(ms,Collections.reverseOrder());
		System.out.println(Arrays.toString(ms));
	}
}
