package ch11;

import java.util.ArrayList;

class GeneT<T>{
	T[] t;
	public void set(T[] t) {
		this.t = t;
		
	}
	public void prn(){
		for(T s :t) {
			System.out.println(s);
		}
	}
}

public class GeneEx1 {
	public static void main(String[] args) {
		GeneT<String> gt = new GeneT<>();//T�� String���� ����
		String[] as = {"���","���","�o��"};
		gt.set(as);
		gt.prn();
		GeneT<Integer> gt2 = new GeneT<>();
		Integer[] i1 = {12,67,77,88,99};
		gt2.set(i1);
		gt2.prn();
		
	}
}
