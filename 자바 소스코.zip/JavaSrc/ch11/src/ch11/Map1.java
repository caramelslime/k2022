package ch11;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
public class Map1 {
	public static void main(String[] args) {
		HashMap<String, String> hm1 = new HashMap<>();
//		        key       value
		hm1.put("BTS", "010-1234-1111");
		hm1.put("������ũ","010-1111-2222");
		hm1.put("������","010-2222-3333");
//		get(key) => ��
		System.out.println(hm1.get("������ũ"));
		Set<String> keys = hm1.keySet(); // HashMap���� key�� �о set�� ��ƶ�
		for(String key: keys) {
			System.out.println(key+" : " +hm1.get(key));
		}
		System.out.println("==================");
		Iterator<String> it = hm1.keySet().iterator();
		while(it.hasNext()) {
			String key = it.next();
			System.out.println(key+" : " +hm1.get(key));
		}
	}
}