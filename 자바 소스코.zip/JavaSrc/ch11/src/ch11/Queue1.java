package ch11;

import java.util.LinkedList;
import java.util.Queue;

public class Queue1 {
	public static void main(String[] args) {
		String[] nations = { "�̱�", "�߱�", "�ѱ�", "����", "�߱�", "�̳k" };
		LinkedList<String> ll = new LinkedList<>();
		for (String nt : nations) {
			ll.offer(nt);
		}
		while (!ll.isEmpty()) {
			System.out.println(ll.poll());
		}
	}
}
