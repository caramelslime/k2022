package ch11;

import java.util.HashSet;
import java.util.Iterator;

public class Set2 {
	public static void main(String[] args) {
		String[] nations = { "�̱�", "�߱�", "�ѱ�", "����", "�߱�", "�̳k" };
		HashSet<String> ll = new HashSet<>();
		for (String nt : nations) {
			ll.add(nt);
			System.out.println(ll);
		}
		Iterator<String> its = ll.iterator();
		while (its.hasNext()) {
			System.out.print(its.next() + "\t");
		}
	}

}
