package ch11;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList3 {
	public static void main(String[] args) {
//		�迭���� �߰�, ������ �������� �ӵ��� �迭�� �� ������.
		ArrayList<String> a1 = new ArrayList<>();
		a1.add("apple");
		a1.add("watermelon");
		a1.add("banana");
		a1.add("strawberry");
		a1.add("watermelon");
		for (int i = 0; i < a1.size(); i++) {
			System.out.print(a1.get(i) + "\t");
		}
		System.out.println();
		a1.add(1, "kiwi");
		for (String fruits : a1) {
			System.out.print(fruits + "\t");
		}
		System.out.println();
		a1.set(3, "grape");
		Iterator<String> its = a1.iterator();
		while (its.hasNext()) {
			System.out.print(its.next() + "\t");
		}
		System.out.println();
		a1.remove(0);
		prn(a1);
		a1.remove("watermelon");
		prn(a1);
		a1.remove("watermelon");
		prn(a1);

	}

	private static void prn(ArrayList a1) {
		System.out.println(a1);

	}
}
