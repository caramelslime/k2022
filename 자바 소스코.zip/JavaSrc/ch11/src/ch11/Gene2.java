package ch11;

import java.util.ArrayList;
import java.util.Arrays;

public class Gene2 {
	public static void main(String[] args) {
		ArrayList<Car> list = new ArrayList<>();
		list.add(new Bus());
		list.add(new Taxi());
		list.add(new FireEngine());
//		list.add(new Ambulance()); Car�� �������� �ʾҴ�
		for(Car car:list) {
			car.print();
			if(car instanceof Bus) {
				((Bus) car).move();
			}
		}
		
	}
}
