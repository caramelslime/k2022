package ch06;
class Student3{
	private String name;
	private int kor,eng,math;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	
	void print() {
		System.out.printf("이름:%s 국어:%d 영어:%d 수학:%d \n",getName(),getKor(),getEng(),getMath());
	}
}
public class Student3Ex {
	public static void main(String[] args) {
		Student3 s1 = new Student3();
		s1.setName("rose");s1.setKor(90);s1.setEng(80);s1.setMath(70);s1.print();
		Student3 s2 = new Student3();
		s2.setName("bogum");s2.setKor(99);s2.setEng(77);s2.setMath(66);s2.print();
				
	}

}
