package ch06;

public class Score1 {
	String name;
	int kor , eng;
	public Score1() {
		this("로제");//this()생성자의 첫째줄 생성자를 호출하여 실행하고 다시 이자리로
		System.out.println("매개변수가 없는 생성자");
	}
	public Score1(String name) {
		this(name,100);
		System.out.println("이름만");
	}
	public Score1(String name , int kor) {
		this(name,kor,80);
		System.out.println("이름과 국어");
	}
	public Score1(String name, int kor ,int eng) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		
		System.out.println("다있는");
	}
	void print() {
		
		System.out.println("고뤠");
	}
	public static void main(String[] args) {
		Score1 s1 = new Score1();
		s1.print();
		
	}
}
