package ch06;
class Person{
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if(age<=1) {
			System.out.println("나이는 1살 이상입니다");
			age=1;
			this.age =age;
		}else this.age = age;
	}

	void print() {
		System.out.println("이름:"+getName()+",나이:"+getAge());
	}
}
public class PersonEx {
	public static void main(String[] args) {
		Person p1 =new Person();
		p1.setName("아이유");p1.setAge(-18);
		p1.print();
	}
}
