package ch06;
class Car1{
	//this는 객체 또는 인스턴스 것이라는 의미
	String color;
	int displayment;
	String kind;
	Car1(String color , int displayment, String kind){
		this.color =color; this.displayment=displayment;this.kind=kind;
	}
	void prn() {
		System.out.println("색깔 :"+color);
		System.out.println("배기량 :"+displayment);
		System.out.println("종류 :"+kind);
		System.out.println("+++++++++++++++++++++++++++++ :");
	}
}
public class Ca1Ex {
	public static void main(String[] args) {
		Car1 c1 = new Car1("red",1500,"sonata");
		c1.prn();
		Car1 c2 = new Car1("yellow",3500,"benz");
		c2.prn();
	}
}
