package ch06;

public class Meth {
	static void hello(String name,int cnt) {
		for(int i =0; i<cnt;i++) {
		System.out.println(name+"님 안녕");
		}
//		return; 메서드의 끝이란뜻 반환없을때 생략가능
	}
	static double add(int x , int y) {
		return x+y;//결과는 반드시 바환형과 같은데이터형이어야한다.
	}
	public static void main(String[] args) {
		hello("은우", 4);
		double b = add(5, 12);
		System.out.println(b);
	}
}
