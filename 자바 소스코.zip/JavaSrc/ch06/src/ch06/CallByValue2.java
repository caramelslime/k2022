package ch06;
class B2{
	 void Swap(int x, int y) {
		int temp;
		temp=x;
		x=y;
		y=temp;
		System.out.println("x:"+x+"y:"+y);
		return;
	}
}
public class CallByValue2 {
	public static void main(String[] args) {
		int x= 10,y=20;
		B2 b2 = new B2();
		b2.Swap(x, y);
		System.out.println("x:"+x+"y:"+y);

		
	}
}
