package ch06;
class A2{
	void remain(int x,int y) {
		System.out.printf("%d %% %d = %d\n",x,y,x%y);
	}
}
public class Add2 {
	static double add2(double x,double y){
		return x+y;
		}
	public static void main(String[] args) {
		A2 a1 = new A2();
		a1.remain(420, 7);
		System.out.println(add2(4.343,89.35));//실수의 연산은 근삿값
		double b1 = add2(5.4,4.2);//데이터형은반환형과 같아야한다
		System.out.println(b1);
		
	}
}

