package ch06;
class Car{
	String company ="현대";
	String model,color;
	int maxSpeed;
	
	Car(){
		this("sonata","은색",250);//마지막생성자로
	}
	Car(String model){
		this(model,"은색",250);
	}
	Car(String model, String color){
		this(model,color,250);
	}
	Car(String model, String color, int maxSpeed){
		this.model=model;
		this.color=color;
		this.maxSpeed=maxSpeed;
	}
	void prn() {
		System.out.println("model:"+model+"color:"+color+"maxSpeed:"+maxSpeed);
	}
}
public class CarEx {
	public static void main(String[] args) {
		Car c = new Car();
		c.prn();
		Car c2 = new Car("benz");
		c2.prn();
		Car c3 = new Car("bmw","검은색");
		c3.prn();
		Car c4 = new Car("kia","빨간색",150);
		c4.prn();
		
		
	}
}
