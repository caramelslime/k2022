package ch06;

public class School {
	public static void main(String[] args) {
		Student4 s1 = new Student4();
		Student4 s2 = new Student4();
		Teacher t = new Teacher();
		Manager m = new Manager();
		s1.setName("로제");s1.setAge(25); s1.setBan("2반");
		s2.setName("보검");s2.setAge(25); s2.setBan("3반");
		t.setName("이준호");t.setAge(31);t.setSubject("자바");
		m.setName("준수");m.setAge(45);m.setPart("청소");
		s1.print1All();s2.print1All();t.print1All();m.print1All();
		
		
	}
}
