package ch06;
class D2 {
	int x, y;
	void swap(D2 d ) {
		int temp;
		temp=d.x; d.x=d.y; d.y=temp;
		System.out.println("swapx="+d.x+",swapy="+d.y);
	}
}
public class CallByRef2 {
	public static void main(String[] args) {
		D2 d2 = new D2();
		d2.x=10;d2.y=20;
		d2.swap(d2);
		System.out.println("mainx="+d2.x+",mainy="+d2.y);
	}
}
