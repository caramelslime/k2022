package ch06;

import java.util.Arrays;

class D1{
	//전달된것은 주소값이다
	void m1(int[] x) {
		x[0]=88;
		x[2]=77;
		System.out.println(Arrays.toString(x));
	}
}
public class CallByRef1 {
	public static void main(String[] args) {
		int[] x = {12,15,17,20};
		D1 d1 = new D1();
		d1.m1(x);
		System.out.println(Arrays.toString(x));// 스텍의 주소에 지정된 힙에 저장된 데이터를 바꾼 것이기 떄문에 메인메서드안의 []x의값도 바뀐것
	}
}
