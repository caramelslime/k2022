package ch06;
class A5{
	void cal(int x ,int y) {
		if(y==0) {
			System.out.println("0으로 나눌수없읍니다");
			return;//아래문장 실행 x 메서드 끝
		}
		System.out.printf("%d+%d=%d\n",x,y,x+y);
		System.out.printf("%d-%d=%d\n",x,y,x-y);
		System.out.printf("%d*%d=%d\n",x,y,x*y);
		System.out.printf("%d/%d=%d\n",x,y,x/y);
		return;
	}
}
public class Return2 {
	public static void main(String[] args) {
		A5 a5 = new A5();
		for(int i=0; i<10 ;i++) {
			a5.cal((int)(Math.random()*10), (int)(Math.random()*10));
		}
	}
}
