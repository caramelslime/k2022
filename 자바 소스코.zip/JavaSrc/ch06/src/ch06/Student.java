package ch06;
public class Student {
	String name;
	int kor;
	int eng;
	int math;
	Student(){}
	Student(int k , int e, int m){
		kor =k; eng = e ; math = m;
	}
	int getTotal() {
		return kor+eng+math;
	}
	void getAverage() {
		System.out.println((double)getTotal()/3);
	}
}
