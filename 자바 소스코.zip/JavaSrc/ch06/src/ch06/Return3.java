package ch06;
public class Return3 {
	public static void main(String[] args) {
		String[] name = {"은우","준오","로제","제니","하니",};
		for (int i = 0 ; i<name.length;i++) {
			String s =call(name[i],i);
			System.out.println(s);
		}
	}
	static String call(String name,int i) {
		String[] hello = {"안녕하세요","헬로","사와디 캅","봉주르","구텐모르겐"};
		return name+hello[i];
	}
}
