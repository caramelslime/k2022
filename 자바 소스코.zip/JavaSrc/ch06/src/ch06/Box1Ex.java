package ch06;
class Box {
	int i_volume;
	double d_volume;
	public Box(int w, int h, int d){
	volume(w, h, d);
	}
	public Box(double w, double h, double d){
		volume(w, h, d);
	}
	private void volume(int w, int h, int d) {
	i_volume = w * h * d;
	}
	private void volume(double w, double h, double d) {
	d_volume = w * h * d;
	}
}

public class Box1Ex {

	public static void main(String args[]) {
		Box mybox1 = new Box(10,20,30);
		Box mybox2 = new Box(10.5,20.5,30.5); 
		Box mybox3 = new Box(10.5,20.5,30);
		System.out.println("정수 박스 부피 : " + mybox1.i_volume);
		System.out.println("실수 박스 부피 : " + mybox2.d_volume);
		System.out.println("정수와실수박스부피: " +mybox3.d_volume);
		}

}
