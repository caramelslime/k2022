package ch06;

public class StudentEx {

	public static void main(String[] args) {
		Student s = new Student(100,60,66);
		s.getTotal();
		System.out.println(s.getTotal());
		s.getAverage();
	}

}
