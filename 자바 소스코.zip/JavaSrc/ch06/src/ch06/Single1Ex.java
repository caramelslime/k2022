package ch06;

public class Single1Ex {
	public static void main(String[] args) {
//		Single1 s1 =new Singel1();//private가아닐때
//		single1 s2 =new single1(); 주소가 다다름
		Single1 s1 = Single1.getInstance();
		Single1 s2 = Single1.getInstance();//singleton 쓰는 이유는 같은 주소를 쓰게해서 메모리아낌
		Single1 s3 = Single1.getInstance();
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}
}
