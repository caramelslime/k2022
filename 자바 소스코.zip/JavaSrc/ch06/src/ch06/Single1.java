package ch06;

public class Single1 {
	//객체를 생성하지않고 사용가능
//	멤버변수에 붙은 경우에는 클래스를 사용하기위해 로딩할때 실행(객체생성할때는 실행안함)
	private static Single1 instance = new Single1();
	private  Single1() {	}
//	퍼블릭 이므로 외부에서 호출 가능하므로 이 메서드를 통하여 객체 생성
	public static Single1 getInstance() {
		return instance;
	}
}
