package ch06;
class A1{
	void add(int x, int y) {//x,y 는 매개변수(parameter)라고 이 메서드를 사용하려면 정수 두개를 넣어
		System.out.printf("%d + %d = %d\n",x,y,x+y);

	}
	void prn(String name) {
		System.out.println(name+"님! 안녕");
	}
	int multiply(int x, int y) {//반환형
		return x*y;
	}
}
public class Add1 {
	static void minus(int x, int y) {//x,y 는 매개변수(parameter)라고 이 메서드를 사용하려면 정수 두개를 넣어
	System.out.printf("%d - %d = %d\n",x,y,x-y);
}
public static void main(String[] args) {
	A1 a1 = new A1();
	a1.add(7, 8);
	a1.add(21, 77);//a1.add(12.4,4.6); 
	a1.prn("철스");
	a1.multiply(5, 4);
	System.out.println(a1.multiply(4, 6));
	minus(5,2);//Add1. 가생략 static 없으면 인스턴스 생성해야함
}
}
