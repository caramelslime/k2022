package ch06;
class B1{
	public void m1(int a, int b) {//변수명은 상관없고 값만 전달
		a+=7;b+=7;
		System.out.println("m1 x= "+a);
		System.out.println("m1 y= "+b);
	}
}
public class CallByValue1 {
	public static void main(String[] args) {
		B1 b1= new B1();
		int x =10,y=20;
		b1.m1(x, y);
		System.out.println("main x ="+x);
		System.out.println("main y ="+y);
	}
}
