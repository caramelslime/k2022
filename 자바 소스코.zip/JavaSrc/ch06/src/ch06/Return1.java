package ch06;
class A3{
	void add(int x ,int y) {
		System.out.printf("%d+%d=%d\n",x,y,x+y);
		return;
	}
	int minus(int x ,int y) {
		return x+y;
	}
	void prn(int x) {
		for(int i=0 ;i<x; i++) {
			if(i==3) return;// 끝
			System.out.println("대박");
		}
	}
}
public class Return1 {
	public static void main(String[] args) {
		A3 a3 = new A3();
		a3.add(14, 24);
		System.out.println(a3.minus(4, 2));
//		System.out.println(a3.add(4, 2)); 출력할 것이 없다.
		a3.prn(10);
	}
}
