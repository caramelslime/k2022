package ch06;
class Student2{
	String name;
	int kor , eng ,mat;
	Student2(String name , int kor , int eng , int mat){
		this.name = name; this.kor = kor ; this.eng = eng; this.mat = mat;
	}
	int getTot() {
		return kor + eng + mat;
	}
	float getAvg() {
		return (float)getTot()/3;
	}
	void prn() {
		System.out.printf("이름 :%s 국어:%d 영어:%d 수학:%d 총점:%d 평균:%.2f\n",name,kor,eng,mat,getTot(),getAvg());
	}
	
	
}
public class Student2Ex {
	public static void main(String[] args) {
		
	
	Student2 s1 = new Student2("제니",80,70,90);
	Student2 s2 = new Student2("이준호",90,88,77);
	Student2 s3 = new Student2("아이유",90,88,99);
	s1.prn();s2.prn();s3.prn();
	}
	
}
