package ch12;
class Thread2 extends Thread{
	public void run() {
		for(int i = 1; i<=20;i++) {
			System.out.print("���"+i+"\t");
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
			}
			if(i%10==0)System.out.println();
		}
		for(int i = 1; i<=20;i++) {
			System.out.print("���"+i+"\t");
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
			}
			if(i%10==0)System.out.println();
		}
	}
}
public class ThreadEx2 {
	public static void main(String[] args) {
		Thread2 th2 = new Thread2();
//		th2.run();
		th2.start();
		for(int i = 1; i<=20;i++) {
			System.out.print("���"+i+"\t");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			if(i%10==0)System.out.println();
		}
	}
}
