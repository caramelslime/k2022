package ch12;
class Thread3 extends Thread{
	public Thread3(String order) {
		super(order);
	}

	public void run() {
		for(int i = 1 ; i<=20;i++) {
			System.out.print(getName()+i+"\t");
			if(i%10==0)System.out.println();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
	}
}
public class ThreadEx3 {
	public static void main(String[] args) {
		Thread3 th1 =new Thread3("ù��°");//�������� �̸�����
		Thread3 th2 =new Thread3("�ι�°");
		th1.start();th2.start();
		
		for(int i = 1 ; i<=20;i++) {
			System.out.print("����"+i+"\t");
			if(i%10==0)System.out.println();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
	}
}
