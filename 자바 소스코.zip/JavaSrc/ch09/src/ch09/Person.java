vpackage ch09;
//최상위 클래스는 오브젝트이므로 extends object 표시하지않음
public class Person {
	int jumin;
	String name;
	int age;
	public Person(int jumin,String name,int age) {
		this.jumin=jumin;this.name=name;this.age=age;
	}
	@Override
	public boolean equals(Object obj) {
//		주민번호 같으면 같다고 정하자
//		if(obj != null && obj instanceof Person) {
//			return jumin == ((Person)obj).jumin;
//		}
//		이름이 같으면 같다고 정하자 문자는 equals로 비교
		if(obj != null && obj instanceof Person) {
			return name.equals(((Person)obj).name);
		}
		
		return false;
	}
	@Override
	public String toString() {//객체를 문자형식으로 출력할 떄 기준
		
		return "주민번호: "+jumin+", 이름:"+name+", 나이:"+age;
	}
//	public boolean equals(Object obj) {
//		return super.equals(obj);
		
	}

