package ch09;

import java.util.Calendar;

public class Cal3 {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		String wk= "";
		switch (cal.get(Calendar.DAY_OF_WEEK)) {
		case Calendar.SUNDAY: wk="일요일";break;
		case Calendar.MONDAY: wk="월요일";break;
		case Calendar.TUESDAY: wk="화요일";break;
		case Calendar.WEDNESDAY: wk="수요일";break;
		case Calendar.THURSDAY: wk="목요일";break;
		case Calendar.FRIDAY: wk="금요일";break;
		case Calendar.SATURDAY: wk="토요일";break;
		}
		System.out.println("오늘은"+wk+"입니다");
	}
}
