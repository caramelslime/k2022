package ch09;

public class StrBuff1 {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		System.out.println(sb+"/"+sb.length()+"/"+sb.capacity());
		sb.append("누구든지 사랑하려면");
		System.out.println(sb+"/"+sb.length()+"/"+sb.capacity());		
		sb.append("남들을 증오 할 때도 있었어");
		System.out.println(sb+"/"+sb.length()+"/"+sb.capacity());
		System.out.println(sb.reverse());
	}
}
