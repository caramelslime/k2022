package ch09;

import java.util.Date;

public class Date1Ex {
	public static void main(String[] args) {
		Date now = new Date();//Deprecated
		System.out.println(now);
//		now.getDate(); 이제 안쓸거임
	}
}
