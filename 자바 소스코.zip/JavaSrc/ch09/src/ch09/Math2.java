package ch09;

public class Math2 {
	public static void main(String[] args) {
		System.out.println(Math.random());
		int num = (int)(Math.random()*100+1);
		System.out.println(Math.sqrt(num));//loot
		System.out.println(Math.pow(2,3));
		
	}
}
