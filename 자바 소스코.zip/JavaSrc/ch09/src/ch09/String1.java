package ch09;

public class String1 {
	public static void main(String[] args) {
		String str1 = "java";//스트링을 기본형 처럼사용
		String str2 = "java";
		String str3 = new String("java"); //스트링을 참조형처럼 사용
//		==의 같다는 의미는 주소가같다
		if(str1 == str2) System.out.println("str1과 str2가같다");
		else System.out.println("str1과str2가 다르다");
		if(str1 == str3) System.out.println("str1과 str3가같다");
		else System.out.println("str1과str3가 다르다");
		System.out.println("================");
//		equals는 주소와 관계없이 내용이 같은것
		if(str1.equals(str2)) System.out.println("str1과 str2가같다");
		else System.out.println("str1과str2가 다르다");
		if(str1.equals(str3)) System.out.println("str1과 str3가같다");
		else System.out.println("str1과str3가 다르다");
	}
}
