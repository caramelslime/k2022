package ch09;

import java.util.Calendar;

public class Cal2 {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
//		월은 0부터시작
		if(cal.get(Calendar.AM_PM) ==0)System.out.println("오전");
		else System.out.println("오후");
		System.out.printf("지금은  %d시 %d분 %d초 입니다",cal.get(Calendar.HOUR),cal.get(Calendar.MINUTE),cal.get(Calendar.SECOND));
		System.out.println();
}
}
