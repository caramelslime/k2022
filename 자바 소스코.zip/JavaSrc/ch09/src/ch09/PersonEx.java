package ch09;

public class PersonEx {
	public static void main(String[] args) {
		Person p1 = new Person(1111,"로제",25);
		Person p4 = new Person(1111,"로제",25);
		Person p2 = new Person(1111,"보검",27);
		Person p3 = new Person(1111,"로제",23);
		
		if(p1==p2)System.out.println("p1괴p2는 같다");
		else System.out.println("p1과p2는 다르다");
		if(p1==p3)System.out.println("p1괴p3는 같다");
		else System.out.println("p1과p3는 다르다");
		if(p1==p4)System.out.println("p1괴p4는 같다");
		else System.out.println("p1과p4는 다르다");
		System.out.println("===============");
		if(p1.equals(p2))System.out.println("p1괴p2는 같다");
		else System.out.println("p1괴p2는 다르다");
		if(p1.equals(p3))System.out.println("p1괴p3는 같다");
		else System.out.println("p1괴p3는 다르다");
//		to String을 재정의 안하면 패키지명.클래스명@해시코드(메모리주소)
		System.out.println("p1 = "+p1);
		System.out.println("p2 = "+p2);
		System.out.println("p3 = "+p3);
	}
}
