package ch09;

import java.util.Arrays;

public class Str4 {
	public static void main(String[] args) {
//					  0 1234 567 890 12 345 6789 01 2
		String str = "우리는 친구였어, 옆에있으면 든-든한 친구";
		System.out.println(str.length());
		System.out.println(str.substring(5,10));
		String[] str1 = str.split(" ");
		System.out.println(Arrays.toString(str1));
		for(String s : str1) {
			if(s.endsWith("는"))System.out.println("는으로 끝나는단어:"+s);
			if(s.startsWith("든"))System.out.println("든으로 시작하는단어:"+s);
		}
		System.out.println(str.indexOf(","));
		System.out.println("===============");
		for(int i=(str.length()-1) ;i>=0;i--)
			System.out.print(str.charAt(i));
	}
}
