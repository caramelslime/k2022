package ch09;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class SimpDateFormat2 {
	public static void main(String[] args) {
		GregorianCalendar gc=new GregorianCalendar(2013,2,5,12,25,30);
		Date date = gc.getTime();

		SimpleDateFormat sd1= new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		SimpleDateFormat sd3= new SimpleDateFormat("(E)yyyy-MM-dd (a) HH:mm:ss");
		System.out.println(sd1.format(date));
		System.out.println(sd3.format(date));
	}
}
