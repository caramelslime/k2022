package ch09;

import java.util.Random;

public class RandomEx {
	public static void main(String[] args) {
		Random ran = new Random();
		System.out.println(ran.nextInt(100));//0~99
		System.out.println(ran.nextInt(101));//0~100
		System.out.println(ran.nextInt(100)+1);//1~100
		System.out.println(ran.nextInt());//int정수 중에서 random
		System.out.println(ran.nextFloat());
		System.out.println(ran.nextDouble());
		System.out.println(ran.nextLong());
		System.out.println(ran.nextBoolean());
		
	}
}
