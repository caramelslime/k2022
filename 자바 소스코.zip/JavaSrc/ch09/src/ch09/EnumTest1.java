package ch09;
enum SchoolType{
	ELEMENTARY,MIDDLE,HIGH,UNIVERSITY//새로운 변수타입 만드는거
}
class Student1{
	SchoolType school;
	public Student1(SchoolType school){
		this.school=school;
	}
}
public class EnumTest1 {
	public static void main(String[] args) {
		Student1 s1 = new Student1(SchoolType.ELEMENTARY);
		if(s1.school==SchoolType.ELEMENTARY)System.out.println("초딩");
		SchoolType[] schools = SchoolType.values();
		for(SchoolType sc:schools) {
//								값		인덱스번호
			System.out.println(sc+":"+sc.ordinal());
		}
	}

}
