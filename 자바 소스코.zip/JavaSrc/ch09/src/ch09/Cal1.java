package ch09;

import java.util.Calendar;

public class Cal1 {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
//		월은 0부터시작
		System.out.printf("오늘은 %d년 %d월 %d일 입니다",cal.get(Calendar.YEAR),cal.get(Calendar.MONTH)+1,cal.get(Calendar.DATE));
		System.out.println();
		System.out.println(cal.get(Calendar.DAY_OF_MONTH));//현재월의 일자
		System.out.println(cal.get(Calendar.DAY_OF_YEAR));//31+28+31+30+31+30+13=
		System.out.println(cal.get(Calendar.WEEK_OF_MONTH));//현재월의 일자
		System.out.println(cal.get(Calendar.WEEK_OF_YEAR));//31+28+31+30+31+30+13=
}
}
