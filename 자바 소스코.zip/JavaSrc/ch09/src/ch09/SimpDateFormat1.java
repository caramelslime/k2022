package ch09;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class SimpDateFormat1 {
	public static void main(String[] args) {
		GregorianCalendar gc=new GregorianCalendar();
		Date date = gc.getTime();
		SimpleDateFormat sd1= new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		SimpleDateFormat sd2= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat sd3= new SimpleDateFormat("(E)yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sd4= new SimpleDateFormat("yyyy-MM-dd (E) (a)HH:mm:ss");
		System.out.println(sd1.format(date));
		System.out.println(sd2.format(date));
		System.out.println(sd3.format(date));
		System.out.println(sd4.format(date));
	}
}
