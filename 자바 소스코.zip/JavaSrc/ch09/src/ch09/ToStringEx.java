package ch09;
class Card{
	String kind;
	int number;
	Card(String kind,int number){
		this.kind=kind;this.number=number;
		}
	@Override
	public boolean equals(Object obj) {
		if(obj != null && obj instanceof Card) {
			return kind.equals(((Card)obj).kind);
		}
		else
			return false;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "카드종류:"+kind+", 번호:"+number;
	}
}
public class ToStringEx {
	public static void main(String[] args) {
		Card[] cd = {new Card("스페이드",10),new Card("스페이드",7),new Card("하트",10)};
		if(cd[0].equals(cd[1]))
			System.out.println("c1과 c2는같다");
		else System.out.println("c1과 c2는 다르다");
		if(cd[0].equals(cd[2]))
			System.out.println("c1과 c3는같다");
		else System.out.println("c1과 c3는 다르다");
		if(cd[1].equals(cd[2]))
			System.out.println("c2과 c3는같다");
		else System.out.println("c2과 c3는 다르다");
		System.out.println("c1:"+cd[0]);
		System.out.println("c2:"+cd[1]);
		System.out.println("c3:"+cd[2]);
	}
}
