package ch17;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class InetAddress1Ex {
	public static void main(String[] args) throws UnknownHostException {
		 
		InetAddress addr1 = InetAddress.getByName("www.choongang.co.kr");
		System.out.println(addr1.getHostAddress());//ip
		System.out.println(addr1.getHostName());//������
	}
}
