package ch17;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class URLConnection1Ex {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BufferedReader br = null ; 
		System.out.println("url �Է��ϼ���");
		String addr = sc.nextLine();
		try {
			URL url = new URL(addr);
			URLConnection uc= url.openConnection();
			InputStream is = uc.getInputStream();
			br = new BufferedReader(new InputStreamReader(is,"utf-8"));
			String str = null;
			while((str = br.readLine()) != null) {
				System.out.println(str);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
