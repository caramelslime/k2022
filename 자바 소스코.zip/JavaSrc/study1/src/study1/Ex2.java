package study1;

import java.util.Arrays;
import java.util.Scanner;

public class Ex2 {
	public static void main(String[] args) {
		Scanner diceinput = new Scanner(System.in);
		
		System.out.println("�ֻ��� �Է�:");
		String str = diceinput.nextLine();
		String[] dice = str.split(" ");
		int[] dices = new int[3];
		for(int i=0;i<dices.length;i++) {
			dices[i]= Integer.parseInt(dice[i]);
		}
		Arrays.sort(dices);
		if(dices[0]<1 || dices[2]>6) {System.out.println("1~6�� ���ڸ� �Է��ϼ���");
		System.exit(0);
		}
		int price = 0;
		if(dices[0]==dices[1] && dices[1]==dices[2]) {
			price = 10000+1000*dices[2];
		}
		else if(dices[0]==dices[1] || dices[1]==dices[2]) {
			price = 1000+100*dices[1];
		}
		else {
			price = dices[2]*100;
		}
		System.out.println("���:"+price);
		
		diceinput.close();
		
	}
}
	