package study1;

public class Ex1 {
	public static void main(String[] args) {
		
		for(int i=0;i<10;i++) {
			for(int j=0;j<10;j++) {
				
				if(2<=j && j<=7) {
					
					if(j==i) {						
						System.out.print("��");
					}	
				}
				if(j==i) continue; 
					
				System.out.print("��");
				
			}
			if(i>7 || i<2)System.out.print("��");
			System.out.println();
		}
		
	}
}