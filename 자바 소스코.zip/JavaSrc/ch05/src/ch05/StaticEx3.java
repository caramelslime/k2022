package ch05;

public class StaticEx3 {
	static int i1 =5,i2=12;//전역변수,인스턴스 변수
	static void add() {
		System.out.printf("%d + %d = %d\n",i1,i2,i1+i2);

	}//static 붙이면 객체생성안해도 사용가능 클래스 이름.인스턴스 변수 or 메서드
	public static void main(String[] args) {
		StaticEx3 s1 = new StaticEx3();
//		int i2 =12;지역변수
//		클래스명과 main()메서드를 가진클래스와 같을경우	static붙어있으면 클래스명 생략가능
		System.out.println("i1 = "+i1);
		System.out.println("i2 = "+i2);
		add();
	}
}