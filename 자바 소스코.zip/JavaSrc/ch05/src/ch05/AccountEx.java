package ch05;
class Account{
	String accountNo;
	String name; 
	int balance;
	public Account (String a,String b, int c) {
		accountNo=a;name=b; balance=c; 
	}
	void deposit(int money) {
		balance+=money;
		System.out.println(name+"입금"+money);
	}
	void withdraw(int money) {
		if(balance>=money) {
			balance-=money;
			System.out.println(name+"출금"+money);
		}
		else 
			System.out.println("잔액이 부족합니다");
	}
	void disp() {
		System.out.println("===계좌번호:"+accountNo);
		System.out.println("예금주:"+name);
		System.out.println("잔액:"+balance);
	}
}

public class AccountEx {

	public static void main(String[] args) {
		
		Account ac1 = new Account("kb1234","이만희",1000);
		Account ac2 = new Account("shinhan3456","전광훈",2000);
		Account ac3 = new Account("woori5678","문선명",3000);
		int money = 0;
		for(int i = 0 ; i<=5;i++) {
			money =(int)(Math.random()*1000)+1;//괄호안치면 0되서 안되요
			ac1.deposit(money);
			money =(int)(Math.random()*1200)+1;
			ac1.withdraw(money);
		}
		ac1.disp();
		for(int i = 0 ; i<=5;i++) {
			money =(int)(Math.random()*1000)+1;
			ac2.deposit(money);
			money =(int)(Math.random()*1200)+1;
			ac2.withdraw(money);
		}
		ac2.disp();
		for(int i = 0 ; i<=5;i++) {
			money =(int)(Math.random()*1000)+1;
			ac3.deposit(money);
			money =(int)(Math.random()*1200)+1;
			ac3.withdraw(money);
		}
		ac3.disp();
		
		
	}

}
