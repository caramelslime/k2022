package ch05;

 class Car2 {
	static String color;
	int displacement;
	String kind;
	void prn() {
		System.out.println("색깔:"+color);
		System.out.println("배기량:"+displacement);
		System.out.println("차종:"+kind);
		System.out.println("==============");
	}
	void speedUp() {//기능 메서드 	반환형 메서드(매게변수) void 반환할것이없다.
		System.out.println("속도를 내고달린다");
	}
	void stop() {
		System.out.println("차를 멈춘다.");
	}
}
public class Car2Ex{
	public static void main(String[] args) {
		Car2.color = "노랑";//클래스를 로딩할떄 초기값 세팅
//		Car2.dispalcement = 1500; instance변수는 반드시 객체를 생성해야 사용가능
		Car2 c1 = new Car2();	Car2 c2 = new Car2();
		
		c1.displacement=1500;c1.kind="bmw";
		c2.displacement=2000; c2.kind="benz";
		c1.prn();c2.prn();
	}
}
