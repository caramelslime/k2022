package ch05;
class Person{
	String name,hobby;
	int age;
	
	Person(){}
	Person(String a){
		name = a;
	}
	Person(String a,int b){
		name = a; age = b; 
	}
	Person(String a, int b, String c){
		name = a; age = b; hobby = c;
	}
	
	void prn() {
		System.out.println("이름:"+name+"나이:"+age+"취미:"+hobby);
	}
}
public class PersonEx {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		p1.age=28;p1.name="IU";p1.hobby="spiting";
		Person p2 = new Person("rose");
		p2.age=25; p2.hobby="insulting";
		Person p3 = new Person("bogum",32);
		p3.hobby="nap";
		Person p4 = new Person("blpin",27,"dance");
		Person[] ps = {p1,p2,p3,p4};
		
		for(Person p : ps) {
			p.prn();
		}
		
		
	}

}
