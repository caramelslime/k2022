package ch05;

public class Car1Ex {

	public static void main(String[] args) {
			Car1 myCar = new Car1();
			myCar.color = "빨강";
			myCar.displacement = 1500;
			myCar.kind="소나타";
			System.out.println("차 색깔:"+myCar.color);
			System.out.println("차 배기량:"+myCar.color);
			System.out.println("차 종류:"+myCar.color);
			myCar.speedUp();
			myCar.stop();
			
			Car1 yourCar = new Car1();
			yourCar.color = "빨강";
			yourCar.displacement = 1500;
			yourCar.kind="소나타";
			System.out.println("차 색깔:"+yourCar.color);
			System.out.println("차 배기량:"+yourCar.color);
			System.out.println("차 종류:"+yourCar.color);
			yourCar.speedUp();
			yourCar.stop();
			
	}

}
