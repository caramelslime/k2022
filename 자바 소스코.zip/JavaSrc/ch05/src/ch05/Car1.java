package ch05;

public class Car1 {
	String color;
	int displacement;
	String kind;
	void speedUp() {//기능 메서드 	반환형 메서드(매게변수) void 반환할것이없다.
		System.out.println("속도를 내고달린다");
	}
	void stop() {
		System.out.println("차를 멈춘다.");
	}
}
