package ch05;
class Box2{
	int width,height,depth;
	Box2(	int	a){
		width = a ;
	}
	Box2( int a,int b){
		width=a; height=b;
	}
	Box2(int a,int b,int c){
		width = a; height =b; depth = c;
	}
	void squre() {
		System.out.println("정사각형의 넓이:"+width*width);
	}
	void rectangle() {
		System.out.println("직사각형의 넓이:"+width*height);
	}
	void volume() {
		System.out.println("직육면체의 부피:"+width*height*depth);
	}
}
public class Box2Ex {

	public static void main(String[] args) {
		Box2 b1 = new Box2(10);
		Box2 b2 = new Box2(10,15);
		Box2 b3 = new Box2(10,15,20);
		
		b1.squre();b2.rectangle();b3.volume();
	}

}
