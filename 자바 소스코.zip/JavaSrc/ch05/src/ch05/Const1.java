package ch05;
class A{
	public A() {
	System.out.println("매개변수가없는 생성자");	
	}
	public A(int k) {
		System.out.println("매개변수가 한개인 생성자"+k);
	}
//	public(int a){//매개변수의 갯수가 같고 데이터형이 같으면 같은 생성자로 인식
//		
//	}
	public A(String a){//매개변수의 갯수가 같고 데이터형이 같으면 같은 생성자로 인식
		System.out.println("//"+a);
	}
	public A(int k1, String k2) {
		System.out.println("메게변수가 2개인 생성자:k1= "+k1+ "k2 = "+k2);
	}
}
public class Const1 {

	public static void main(String[] args) {
		A a = new A();
		A b = new A(12);
		A c = new A("데박");
		A d = new A(4,"헐");
		
		
	}

}
