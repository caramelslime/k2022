package ch05;
class Static1{
	int var1 =100;// 객체를 생성해야 사용가능
	static int var2 =200;// 클래스 변수 클래스를 로딩하자마자 바로사용
	void prn1(){//객체를 생성해야 사용가능
		System.out.println("var1 ="+var1);
		System.out.println("var2 ="+var2);
	}
	static void prn2(){//클래스 메서드 객체를 생성하지마 않고 바로사용가능한 메서드, 클래스를 로딩하고 바로사용
//		System.out.println("var1 ="+var1); 객체가 생성되지않는 상태에서 사용못하는 변수
		System.out.println("var2 ="+var2);	
	}
}
public class Static1Ex {

	public static void main(String[] args) {
		Static1.prn2();
//		Static1.prn1(); 인스턴스 메서드는 객체를 생성해야 사용가능
		Static1 s1 =new Static1();
		s1.prn1();
		s1.var1=200;
		s1.prn1();
	}

}
