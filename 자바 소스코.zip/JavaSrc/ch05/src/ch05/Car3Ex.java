package ch05;
class Car3{//모든 클래스는 생성자를 가지고있음,생성자가 없는 경우에는 컴파일러가 default생성자를 만들어준다.
// 기본생성자란? 매개변수가 없고 구현문이 없는 생성자
	String color;
	int displacement;
	String kind;
	Car3() {}//생성자,메서드와 유사한 모양이지만 반환형이없다.
//	생성자가 여러개일 경우에는 매개변수의 갯수가 다르거나 데이터형이 달라야한다,생성자 over loading
	Car3(String a,int b, String c){//이름이 클래스와 일치
		color =a; displacement = b; kind= c;
	}
	void prn(){
		System.out.println("색깔:"+color);
		System.out.println("배기량:"+displacement);
		System.out.println("차종:"+kind);
		System.out.println("======================");
	}
}
public class Car3Ex {

	public static void main(String[] args) {
		Car3 car1 = new Car3();//기본생성자가 필요하다
		Car3 car2 = new Car3("파랑",2000,"벤치치");
		car2.prn();
	}

}
