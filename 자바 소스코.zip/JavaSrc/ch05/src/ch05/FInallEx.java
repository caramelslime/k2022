package ch05;
class Final{
	
}
public class FInallEx {

	public static void main(String[] args) {
		final double PI = 3.14;//파이널은 수정못하게 다대문자로
		int r = 10;
		System.out.printf("반지름이 %d인 원의 넓이 = %.2f\n",r,r*r*PI);
		r=20;
//		PI = 3.141592; final변수는 수정불가
		System.out.printf("반지름이 %d인 원의 넓이 = %.2f\n",r,r*r*PI);
		
	}

}
