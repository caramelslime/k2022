package ch05;
class Score1{
	String name;
	int kor, eng , math;
	void print() {
		int sum; //지역변수: 해당하는 메서드에서만 사용가능하고 다른메서드 에서는 사용할수 없다.
		System.out.println(name+"의 성적");
		System.out.printf("국어:%d\t영어:%d\t수학:%d\n",kor,eng,math);
		System.out.println("총점 : "+(kor+eng+math));
		System.out.printf("평균:%.2f\n",(double)(kor+eng+math)/3);
		
	}
}
public class Score1Ex {

	public static void main(String[] args) {
		Score1 str1 = new Score1();
		Score1 str2 = new Score1();
		Score1 str3 = new Score1();
		
		str1.name="jenny";
		str1.eng=88;str1.kor=77;str1.math=99;
		str2.name="bogum";
		str2.eng=77;str2.kor=66;str2.math=90;
		str3.name="rose";
		str3.eng=92;str3.kor=88;str3.math=93;
		
		str1.print();
		str2.print();
		str3.print();
		
		
	}

}
