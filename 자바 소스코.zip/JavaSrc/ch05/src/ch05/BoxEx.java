package ch05;

public class BoxEx {
	public static void main(String[] args) {
		Box box1 = new Box();
		Box box2 = new Box();
		box1.width=20;
		box1.height=25;
		box1.depth=50;
		box1.calVolume();
		
		box2.calVolume();

		
	}
}
