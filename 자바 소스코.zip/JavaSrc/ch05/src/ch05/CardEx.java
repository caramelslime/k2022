package ch05;
class Card{
//	static String [] card = {"스페이드","하트","다이아몬드","클로바"};
	int num ;
	String card ;
	static int width,height; 
	void prn(){
//		System.out.println("카드 종류"+card[(int)Math.random()*4]);
		System.out.println("카드 종류:"+card);
		System.out.println("카드번호:"+num );
		System.out.printf("가로길이:%d 세로길이:%d\n",width,height);
		System.out.println("========================");
	}
	
}
public class CardEx {

	public static void main(String[] args) {
		Card.width = 100; Card.height=250;
		Card cd1 = new Card();
		Card cd2 = new Card();
		Card cd3 = new Card();
		cd1.card= "스페이드"; cd1.num = 7;
		cd2.card= "하트"; cd2.num = 1;
		cd3.card= "클로버"; cd3.num = 10;
		cd1.prn();cd2.prn();cd3.prn();
		
		
	}

}
