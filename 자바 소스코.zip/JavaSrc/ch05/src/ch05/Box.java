package ch05;

public class Box {
		
	//객체를 생성한 후에 사용하는 변수 instance변수 (멤버 변수)
	public	int width,height,depth;//전역변수:여러 메서드에서 사용가능 
		
		public void calVolume() {
			System.out.println("부피:"+width*height*depth);
		}
	}


