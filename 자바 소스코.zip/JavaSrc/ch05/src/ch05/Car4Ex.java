package ch05;

import java.util.Scanner;

class Car4{
	String carNo;
	String inTime;
	String outTime;
	int fee;
	final int MONEY_PER_HOUR=5000;
	Car4(){}
	Car4(String a,String b,String c){
		carNo=a;inTime=b;outTime=c;
	}
	void calFee() {
		fee=(Integer.parseInt(outTime)-Integer.parseInt(inTime))*MONEY_PER_HOUR;
	}
	void prn() {
		System.out.printf("차량번호:%s ,입고시간:%s ,출고시간:%s ,주차요금:%d\n",carNo,inTime,outTime,fee);
		System.out.println("============================================");
	}
}
public class Car4Ex {

	public static void main(String[] args) {
		Car4 car1 = new Car4("가1234","10","13");
		Car4 car2 = new Car4("나4567","9","18");
		Car4 car3 = new Car4("다9876","11","16");
		Car4[] cars = {car1,car2,car3};
		//		car1.calFee();car2.calFee();car3.calFee();
//		car1.prn();car2.prn();car3.prn();

		for(Car4 car:cars) {
			car.calFee();car.prn();
		}
		for(int i = 0 ; i<cars.length;i++) {
			Scanner sc= new Scanner(System.in);
			System.out.print("차량번호를 입력하세요:");
			String a = sc.nextLine();
			System.out.print("입고시간을 입력하세요:");
			String b = sc.nextLine();
			System.out.print("출고시간을 입력하세요:");
			String c = sc.nextLine();
			cars[i]=new Car4(a,b,c);
			sc.close();
		}
		for(Car4 car:cars) {
			car.calFee();car.prn();
		}
		System.out.println("program over");
		
	}
	
	}
	
