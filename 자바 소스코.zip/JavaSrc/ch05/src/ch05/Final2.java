package ch05;

import java.util.Scanner;

public class Final2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		프로그램이해가 쉽다,변경금지
		final int CIRCLE = 1;
		final int RECTANGLE = 1;
		final int TRIANGLE = 1;
		while (true) {
			System.out.println("정수 1,2,3,중 하나 입력하세요");
			int num =sc.nextInt();
			if(num ==0) break;
			if(num==CIRCLE)System.out.println("원입니다");
			else if(num==RECTANGLE)System.out.println("사각형입니다");
			else if(num==TRIANGLE)System.out.println("삼각형입니다");
			else System.out.println("정수 1,2,3,중 하나 입력하세요");
			
			
		}
		System.out.println("program over");
		sc.close();
	}
}
