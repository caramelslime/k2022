package ch02;

public class Substutute1 {

	public static void main(String[] args) {
		int k1 = 10;
		k1 = k1 +8;
		k1 += 10;
		System.out.println("k1 = " +k1);
	}

}
