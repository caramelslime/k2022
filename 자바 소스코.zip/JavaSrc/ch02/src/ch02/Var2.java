package ch02;

public class Var2 {

	public static void main(String[] args) {
		int i1;// 변수선언, 메모리에 공간확보
		i1 = 34;// 변수에 값 대입
		int i2= 56;
		System.out.println(i1);
		System.out.println(i2);
		byte b1 = 127;//-128 ~127
		System.out.println(b1);
	}

}
