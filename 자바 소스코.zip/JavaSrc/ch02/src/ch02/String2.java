package ch02;

public class String2 {
	public static void main(String[] args) {
		System.out.println(2+0+2+2+"년도");
		//년도 : 2 +숫자0이문자로 변경
//		범위가 다른 데이터형의 연산은 범위가 큰 쪽으로 변경
		System.out.println("년도 :"+2+0+2+2);
	}
}
