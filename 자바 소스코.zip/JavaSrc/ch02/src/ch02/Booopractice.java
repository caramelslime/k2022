package ch02;

public class Booopractice {

	public static void main(String[] args) {
		boolean b1 = 3>5;
		System.out.println(b1);
	}

}
