package ch02;

public class Oper1 {

	public static void main(String[] args) {
		int i1 = 7, i2 = 5;
		boolean b1 = i1==i2, b2 = i1!=i2;
		System.out.println("i1+i2=" +(i1+i2));
		System.out.println("i1%i2=" +(i1%i2));
		System.out.println("i1>i2=" +(i1>i2));
		System.out.println("i1==i2=" +b1);
		System.out.println("i1!=i2=" +b2);
		System.out.println("i1==i2 && i1!=i2=" +(b1&&b2));
		System.out.println("i1==i2 || i1!=i2==" +(b1||b2));

		int k1 = i1++ *3 + --i2;
		System.out.println("i1 = " +i1+ ",i2 = " +i2+ "."+k1+"=i1++ *3 + --i2 ");
		
	}

}
