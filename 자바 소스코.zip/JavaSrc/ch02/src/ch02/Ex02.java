package ch02;

public class Ex02 {

	public static void main(String[] args) {
		int num= 456;//int /int 는 결과도 정수
		System.out.println(num/100*100);
	}

}
