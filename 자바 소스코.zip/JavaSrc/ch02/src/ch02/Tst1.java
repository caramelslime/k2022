package ch02;

public class Tst1 {
	public static void main(String[] args) {
		int a=1, b=1;
		int c= a++,d=++b;
		System.out.println(a+","+b);
		System.out.println(c+","+d);
	}
}
