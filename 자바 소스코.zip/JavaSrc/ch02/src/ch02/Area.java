package ch02;

public class Area {
	public static void main(String[] args) {
		double pi = 3.141592;
		int r1 = 10;
//		연산의 결과는 범위가 큰쪽 형을 따름
		double area = pi*r1*r1;
		System.out.println(pi+ "* "+r1*r1+"= "+area);
		System.out.printf("%f * %d = %f",pi, r1*r1,area);
	}
}
