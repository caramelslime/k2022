package ch02;

public class Cast2 {

	public static void main(String[] args) {
		byte a =35;
		int	b = a ;
		byte c = (byte) b; // 범위가 넓은 곳에서 범위가 좁은 곳 다운 캐스팅(강제)형변환
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("c="+c);
	}

}
