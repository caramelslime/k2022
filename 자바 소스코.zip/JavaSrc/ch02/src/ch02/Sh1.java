package ch02;

public class Sh1 {
	public static void main(String[] args) {
		int num=10;
		System.out.println("num>>2="+(num>>2));
		System.out.println("num<<2="+(num<<2));
	}
}
