package ch02;

public class Char2 {

	public static void main(String[] args) {
		char c1 = 'A';
//		char c2 = '';
//		char c3 = 'aa';
		char c3 = '\u0041';
		char c4 = '헐';
//		char c5 = "a"; 
		System.out.println("c1="+c1);
		System.out.println("c3="+c3);
		System.out.println("c4="+c4);
	}

}
