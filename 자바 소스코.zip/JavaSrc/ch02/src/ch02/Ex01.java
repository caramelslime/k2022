package ch02;

public class Ex01 {

	public static void main(String[] args) {
		int numOfApples = 123;
		int sizeOfBucket =10;
		int numOfBucket = numOfApples%sizeOfBucket>0 ? numOfApples/sizeOfBucket+1:numOfApples/sizeOfBucket;
		System.out.printf("%d개의 사과를 담는데 필요한 바구니 개수는 %d개 입니다",numOfApples,numOfBucket);
		
	}

}
