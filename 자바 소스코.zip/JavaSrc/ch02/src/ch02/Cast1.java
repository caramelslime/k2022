package ch02;
// 형변환 : (데이터형 )값;
// 현재의 데이터형을 다른 데이터 형으로 변환
public class Cast1 {

	public static void main(String[] args) {
		System.out.println((char)65);
		System.out.println((int)'A');
		System.out.println((int)1.6);
		System.out.println((float)10);
	}

}
