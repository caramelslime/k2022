package ch02;

public class Cast3 {
//쓰레기값나옴
	public static void main(String[] args) {
		byte a = (byte) 128;
		System.out.println("a="+a);
		byte b = (byte)256;
		System.out.println("b="+b);
	}

}
