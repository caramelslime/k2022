package ch02;

public class Mono {
// i1++ 출력후 증가 ++i2 증가후 출력
	public static void main(String[] args) {
		int i1 =5, i2 =5;
		System.out.println("i1="+i1++ + ",i2="+ ++i2);
		System.out.println("i1="+i1 + ",i2="+ i2);
		System.out.println("i1="+i1-- + ",i2="+ --i2);
		System.out.println("i1="+i1 + ",i2="+ i2);
		}

}
