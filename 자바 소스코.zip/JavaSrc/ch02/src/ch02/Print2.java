package ch02;

public class Print2 {
	public static void main(String[] args) {
		System.out.println("홍\n길\n동");// \n line feed 줄바꿈
		System.out.println("홍동\r길홍\r동길");// \r carriage return 커서를 앞으로가라
		System.out.println("홍\t길\t동");// \t tab 8칸 앞으로
//		enter =/r + /n = CR+LF
	}
}
