package ch02;

public class Spec1 {
	public static void main(String[] args) {
		System.out.println("대\t박\t사\t건");
		// \이거 뒤에 오는건 그냥 문자로 취급
		System.out.println("\"");
		
	}

}
