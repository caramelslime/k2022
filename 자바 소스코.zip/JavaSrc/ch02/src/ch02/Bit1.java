package ch02;

public class Bit1 {
	public static void main(String[] args) {
		int num1=10,num2 =6;
		System.out.println("num1 & num2=" +(num1&num2));
		System.out.println("num1 | num2=" +(num1|num2));
		System.out.println("num1 ^ num2=" +(num1^num2));
		System.out.println("~num1=" +(~num1));
	}
}
