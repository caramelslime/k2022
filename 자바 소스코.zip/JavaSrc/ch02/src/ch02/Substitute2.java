package ch02;

public class Substitute2 {

	public static void main(String[] args) {
		int i1 =10;
		System.out.println("i1+="+(i1 += 4));
		i1 -= 4;
		System.out.println("i1-="+i1);
		i1 *=4;
		System.out.println("i1*="+i1);
		i1 /=4;
		System.out.println("i1/="+i1);
		i1 %=4;
		System.out.println("i1%="+i1);
	}

}
