package ch02;

public class Var1 {
	public static void main(String[] args) {
		int i1 = 27;
		int i2 = 12;
		System.out.println(i1+i2);
		System.out.println(0.1+0.2);
	}

}
