package ch02;

public class Tri2 {
	public static void main(String[] args) {
		int num1 =234,num2=250, noperpage = 10;
		int page1= num1%noperpage>0? num1/noperpage+1:num1/noperpage;
		int page2= num2%noperpage>0? num2/noperpage+1:num2/noperpage;
		
		System.out.println("num1에필요한 페이지는"+page1+"페이지 입니다");
		System.out.println("num2에필요한 페이지는"+page2+"페이지 입니다");
		
	}
}
