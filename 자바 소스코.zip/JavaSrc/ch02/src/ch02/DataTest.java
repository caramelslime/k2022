package ch02;

public class DataTest {

	public static void main(String[] args) {
		String a= "데이터형과 변수 예제";
		byte b= 5;
		short c= 10;
		int d = 100;
		long e = 100L;
		float f = 12.34f;
		double g = 123.345;
		char h = 'a';
		boolean i = false;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
	}

}
