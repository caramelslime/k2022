package ch02;

public class BitLogic1 {

	public static void main(String[] args) {
		int a = 4;
		int b = 7;
		System.out.println("| = " + (a | b)); // 모두 거짓일 때 거짓
		System.out.println("& = " + (a & b)); // 모두 참일 때 참
		System.out.println("^ = " + (a ^ b)); // 양쪽이 틀리면 참
		
	}

}
