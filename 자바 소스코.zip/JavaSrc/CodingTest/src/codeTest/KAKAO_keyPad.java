package codeTest;

public class KAKAO_keyPad {

}
class Solution5 {
    public String solution(int[] numbers, String hand) {
        String answer = "";
        int Lloc = 0,Rloc=0;
        for(int i = 0 ; i<numbers.length;i++) {
        	if(numbers[i]%3==1) {
        		answer+="L";
        		Lloc=numbers[i];
        	}
        	else if(numbers[i]%3==0&&numbers[i]!=0) {
        		answer+="R";
        		Rloc=numbers[i];
        	}
        	else if(numbers[i]==0) {
        		if(Math.abs(Lloc-Rloc)==2||Lloc==Rloc) {
        			answer+=hand.substring(0).toUpperCase();
        		}
        		else answer=(Lloc>Rloc)? "L":"R";
        	}
        	else {
        		if(Math.abs(Lloc-Rloc)==2) {
        			answer+=hand.substring(0).toUpperCase();
        		}
        		else {
        			if()
        		}
        	}
        }
        return answer;
    }
}