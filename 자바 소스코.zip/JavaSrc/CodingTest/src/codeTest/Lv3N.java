package codeTest;

import java.util.ArrayList;
import java.util.HashSet;

public class Lv3N {

}
class Solution12 {
    public int solution(int N, int number) {
        int answer = 0;
        if(number == N) return answer =1;
        ArrayList<HashSet<Integer>> a1 = new ArrayList<>();
        HashSet<Integer> h1 = new HashSet<>();

        for(int i =1 ; i<=8;i++) {
        	for(int j = 1 ;j<=i ;j++) {
        		for(int k = 1 ; k<=j;k++) {
        			for(int m = 0 ; m<j-k;m++) {
        				
        			}
        		}
        	}
        }
        		
        
        
        
        return answer;
    }
}