package codeTest;

public class Idontwannadie {
	public static void main(String[] args) {
		String str = "..ad...da.ad.da.";
		str.replaceAll(".{2,}", ".");
		System.out.println(str);
	}
}
