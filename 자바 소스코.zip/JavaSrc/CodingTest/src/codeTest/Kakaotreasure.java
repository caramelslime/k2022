package codeTest;

public class Kakaotreasure {
	public static void main(String[] args) {
		int[] arr1 = {9,17,4};
		int n = 5;
		String map1 = "";
		for(int j =n-1; j>=0 ;j--) {
    		if(1==arr1[0]/(int)Math.pow(2, j)) {
    			map1+="#";
    			arr1[0]%=Math.pow(2, j);
    		}
    		else if(0==arr1[0]/(int)Math.pow(2, j)) {
    			map1+=" ";
    		}
    		System.out.println("a="+map1);
    		System.out.println(Math.pow(2, n));
		}
	}
}
class Solution123 {
    public String[] solution(int n, int[] arr1, int[] arr2) {
        String[] answer = new String[n];
        String map1="",map2="",map="";
        for(int i = 0 ; i<n;i++){	
        	for(int j =n-1; j>0 ;j--) {
        		if(1==arr1[i]/Math.pow(2, j)) {
        			map1="#";
        			arr1[i]%=Math.pow(2, j);
        		}
        		else if(0==arr1[i]/Math.pow(2, j)) {
        			map1=" ";
        		}
        		if(1==arr2[i]/Math.pow(2, j)) {
        			map2="#";
        			arr2[i]%=Math.pow(2, j);
        		}
        		else if(0==arr2[i]/Math.pow(2, j)) {
        			map2=" ";
        		}
        		if(map1.equals("#") || map2.equals("#"))map+="#";
        		if(map1.equals(" ") && map2.equals(" "))map+=" ";
        	}
        	answer[i]=map;
        	map="";
        }
        return answer;
    }
}