package codeTest;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

@FunctionalInterface
interface Rectangle{
	int vol(int x ,int y);
}
public class Ex1 {
	public static void main(String[] args) {
		Rectangle rt;
		int width=15,height=18;
		rt = (x,y)->  x*y;
		System.out.println("�簢���� ����:"+rt.vol(width, height));
		boolean a = (0.9==0.9f);
		System.out.println(a);
	      String str1 = 10.0 + "�߾�";
	       String str2 = 5 + str1;
	       String str3 = str2 + 8.0;
	       System.out.println(str3);
	}	
}
