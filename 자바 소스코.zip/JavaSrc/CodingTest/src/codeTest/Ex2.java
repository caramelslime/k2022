package codeTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ex2 {
	public static void main(String[] args) {

		int[] f = new int[4];
		f[0]=1;
		System.out.println(Arrays.toString(f));
		
		
	}
	class Solution {
	    public ArrayList<Long> solution(long k, long[] room_number) {
	        ArrayList<Long> answer = new ArrayList<Long>();
	        long reserved=0;
	        long max=0;
	        for(int a=0 ; a<room_number.length;a++) {
	        	for(int b=0 ; b<a;b++) {
	        		if(room_number[a]==room_number[b]) break;
	        		else reserved=room_number[a];
	        	}
	        	for(long b:answer) {
	        		if(b>max) max=b;
	        	}
	        	if(reserved!=0)answer.add(reserved);
	        	else answer.add(max+1);
	        }
	        return answer;
	    }
	}
}