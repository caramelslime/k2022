package codeTest;

public class NUMplay {
	public static void main(String[] args) {
		String str = "2three45sixseven";
		String a= "",b="";
		a=str;
		System.out.println(a);
			for(int i = 0 ; i<a.length()-2;i++) {
				
					b=a.substring(i,i+2);
					System.out.println(b);
					switch (b) {
					case "ze":
						a=a.replaceFirst("zero","0");
						break;
					case "on":
						a=a.replaceFirst("one","1");
						break;
					case "tw":
						a=a.replaceFirst("two","2");
						break;
					case "th":
						a=a.replaceFirst("three","3");
						break;
					case "fo":
						a=a.replaceFirst("four","4");
						break;
					case "fi":
						a=a.replaceFirst("five","5");
						break;
					case "si":
						a=a.replaceFirst("six","6");
						break;
					case "se":
						a=a.replaceFirst("seven","7");
						break;
					case "ei":
						a=a.replaceFirst("eight","8");
						break;
					case "ni":
						a=a.replaceFirst("nine","9");
						break;
	
					default:
						break;
					}
				
			}
System.out.println(a);
	}
}
