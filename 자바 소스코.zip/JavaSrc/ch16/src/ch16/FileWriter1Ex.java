package ch16;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWriter1Ex {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("���ϸ�:");
		String fileName = sc.nextLine();
		System.out.println("���Է�:");
		String msg = sc.nextLine();
		FileWriter fw = new FileWriter(fileName);
		fw.write(msg);
		System.out.println("��������Ϸ�");
		fw.close();sc.close();
	}
}
