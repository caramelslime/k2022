package ch16;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.GregorianCalendar;
public class ObjectReadEx1 {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream("data.txt"));
			while(true) { // �����Ͱ� ��ǿӴ��� ����
				GregorianCalendar gc = (GregorianCalendar) ois.readObject();
				System.out.printf("%TF\n", gc);
			}
		} catch (EOFException e) {//EOF�� END OF FILE
			System.out.println("������ ������");
		} finally {
			ois.close();
		}
	}
}
