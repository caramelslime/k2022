package ch16;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FIleReader1Ex {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("���� ���ϸ�:");
		String file = br.readLine();
		BufferedReader fr = new BufferedReader(new FileReader(file));
		while(true) {
			String str = fr.readLine();
			if(str == null)break;
			System.out.println(str);
		}
		br.close(); fr.close();
		System.out.println("����");
	}
}
