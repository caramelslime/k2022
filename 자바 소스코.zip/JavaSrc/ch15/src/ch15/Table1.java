package ch15;

import javax.swing.JFrame;

public class Table1 extends JFrame{
	
}
