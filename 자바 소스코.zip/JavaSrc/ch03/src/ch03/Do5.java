package ch03;

import java.io.IOException;

public class Do5 {
	public static void main(String[] args) throws IOException {
		System.out.println("숫자입력");
		int i = System.in.read() - '0';
		int gop = 1;
		System.out.println("구구단");
		System.out.println("==========");
		do {
			
			System.out.println(i+"*"+gop+"="+i*gop);
			gop++;
		}while(gop<10);
	}
}
