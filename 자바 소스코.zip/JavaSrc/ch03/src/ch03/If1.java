package ch03;

public class If1 {
//	String[] args 매개변수 운영할 때 편함
	public static void main(String[] args) {
//		문자열을 정수로 변경하는 메소드 Integer.parseInt()
		int i1= Integer.parseInt(args[0]);
		if(i1 >0) {
			System.out.println(i1+"은 양수");
			System.out.println("박대 사건");
		}	
		else {
			System.out.println(i1+"은 음수");
			System.out.println(-i1+"절대값으로 변경");
		}
		System.out.println("프로그램 종료");
	}

}
