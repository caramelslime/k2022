package ch03;

public class Ex01 {

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
//		String b="";
		if(a<10)
			System.out.println("10미만입니다");
		else if(a>=10&&100>a)
			System.out.println("10이상 100미만입니다");
		else if(a>=100 &&1000>a)
			System.out.println("100이상 1000미만입니다");
		else
			System.out.println("1000이상입니다");
	//b="1000이상입니다";
		//System.out.printf("입력값%d 결과 %s이다",a,b);
		
		
	}

}
