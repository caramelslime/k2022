package ch03;

public class While3 {
	public static void main(String[] args) {
		int i =1 , sum = 0;
		while( i <11) {
			sum+= i;
			i++;
	
		}
		System.out.println(sum);
	}
}
