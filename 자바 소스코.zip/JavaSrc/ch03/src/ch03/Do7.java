package ch03;

import java.io.IOException;

public class Do7 {
	public static void main(String[] args) throws IOException {
		int j=1 , i= 2 ;
		System.out.println("구구단 ");
		System.out.println("=========== ");
		do {

			do {
				System.out.printf("%d * %d = %d\t",i,j,j*i);
				j++;
			}while(j<=9);
			System.out.println();
			j=1;
			i++;
		}while(i<10);
			System.out.println("프로그램종료");
	}
}
