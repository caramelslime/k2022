package ch03;

public class Ex2 {

	public static void main(String[] args) {
		int sum=0,tosum=0;
		for(int i=1;i<=10;i++){
			for(int j=1;j<=i;j++)
				sum+=j;
			tosum+=sum;
			sum=0;
		}//그냥 sum+=j; tosum+=sum; 해도됨
		System.out.println(tosum);//1+(1+2) ---- (1+2+----+10)의결과

	}

}
