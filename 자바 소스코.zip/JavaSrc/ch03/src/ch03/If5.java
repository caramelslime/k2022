package ch03;

public class If5 {

	public static void main(String[] args) {
		int money = Integer.parseInt(args[0]);
		if(money>=1000000)
			System.out.println("비행기타세요");
		else if(money>=100000)
			System.out.println("KTX타세요");
		else if(money>=10000)
			System.out.println("택시 타세요");
		else if(money>=5000)
			System.out.println("버스나타세요");
		else 
			System.out.println("걸어다니셈");
	}

}
