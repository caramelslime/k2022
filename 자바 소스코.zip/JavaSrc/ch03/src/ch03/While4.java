package ch03;

import java.io.IOException;

public class While4 {

	public static void main(String[] args) throws IOException {
		System.out.println("보고 싶은 구구단은?");
		int num = System.in.read() - '0';// 문자에서 0의 아스키값을 빼서 정수처럼쓰는것
		int a=1, b=0;
		while(a<10) {
			b= a * num;
		System.out.println(num+"*" +a+ "="+b);	//걍num*a쓰기;
		a++;
		}
		
	}

}
