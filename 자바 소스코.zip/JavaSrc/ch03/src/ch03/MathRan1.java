package ch03;

public class MathRan1 {

	public static void main(String[] args) {
		//Math.random() : 0~1미만의 실수를 임의로생성
		System.out.println((int)(Math.random() * 100)+1);
	}

}
