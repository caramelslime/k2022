package ch03;

import java.util.Scanner;

public class For4 {

	public static void main(String[] args) {
		System.out.println("구구단 시작~");
		System.out.println("+++++++++++++++++");
		Scanner sc = new Scanner(System.in);
		int num = Integer.parseInt(sc.nextLine());
		if(num>=2&&9>=num) {
			for(int i=1; i<=9; i++) {
				System.out.printf("%d * %d = %d \n",num,i,num*i);
			}
			}
		else
			System.out.println("2~9까지의 숫자를 입력하세요");
		
	}

}
