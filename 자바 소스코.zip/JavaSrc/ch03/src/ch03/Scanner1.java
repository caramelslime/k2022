package ch03;

import java.util.Scanner;

public class Scanner1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = "";
		do {
			System.out.println("문자를 입력하세요");
			str = sc.nextLine();
			System.out.println("입력한 문자 :"+str);
			if(str.equals("x"))//숫자끼리 같다 == 문자 내용이 같다 equals
				break;
		}while(true);
		System.out.println("program over");
		sc.close();
	}

}
