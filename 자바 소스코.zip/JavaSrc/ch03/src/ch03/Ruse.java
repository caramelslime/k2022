package ch03;

public class Ruse {

	public static void main(String[] args) {
		System.out.println("\r바 \r 보");
	}

}
