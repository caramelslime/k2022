package ch03;

public class Sw2 {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		// 변수 msg 사용가능 mas= 안녕하세요; System.out.println(msg);
		switch(num) {
		case 1:System.out.println("안녕하세요");break;
		case 2:System.out.println("반갑습니다");break;
		case 3:System.out.println("첨 뵈요");break;
		default:System.out.println("누구쇼");	
		}
	}

}
