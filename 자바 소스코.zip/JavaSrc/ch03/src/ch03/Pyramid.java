package ch03;

public class Pyramid {

	public static void main(String[] args) {
		for(int i=1;i<=20;i++){
			for(int j =19;j>=i;j--) {
				System.out.print(" ");

			}
			for(int k =1;k<=2*i-1;k++)
				System.out.print("*");
			System.out.println();
		}
	}

}
