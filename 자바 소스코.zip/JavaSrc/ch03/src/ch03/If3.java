package ch03;

public class If3 {

	public static void main(String[] args) {
		int score=Integer.parseInt(args[0]);
		if(100>=score&&score>=60)
			System.out.println("합격");
		else if(score<60&&score>=0)
			System.out.println("불합격");
		else
			System.out.println("오류");
	}

}
