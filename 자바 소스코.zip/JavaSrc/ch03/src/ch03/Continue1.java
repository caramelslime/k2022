package ch03;

public class Continue1 {

	public static void main(String[] args) {
		a:for(int i =0;i<10;i++) {
			for(int j=0;j<10;j++) {
				System.out.println("안쪾"+j);
				if(j>3) continue;//3전이면 대박 출력 
//				if(j>3) continue a;
				System.out.println("대박쪾"+j);
			}
		System.out.println("밖쪾"+i);
	}
	}
}
