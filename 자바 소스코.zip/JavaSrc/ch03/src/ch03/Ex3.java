package ch03;

public class Ex3 {
	public static void main(String[] args) {
		int i,j;
		for(i=1;i<=6;i++)
			for(j=1;j<=6;j++) {
				if(6==i+j)
					System.out.printf("(%d.%d)\n",i,j);
			}
	}
}
