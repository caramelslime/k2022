package ch03;
// if switch 중복
public class Sw8Up {

	public static void main(String[] args) {
		int salary = Integer.parseInt(args[0]);
		String grade = "";
		if(salary <=1000000) {//70만 이하를 c로만들고싶으면 1을뺌 salary -1;
			switch (salary/100000) {
			case 10: grade="A";break;
			case 7: case 8: case 9: grade= "B" ; break;
			case 5: case 6: grade= "C" ; break;
			case 3: case 4: grade= "D" ; break;
			default: grade= "F"; break;
		}}
		else
			grade="A";
		System.out.printf("월급는 %d이고 등급은%s입니다",salary,grade);
	}

}
