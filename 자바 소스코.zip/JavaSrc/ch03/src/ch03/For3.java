package ch03;

public class For3 {

	public static void main(String[] args) {
		int sum = 0;
//		for(int i = 0; i<=100 ; i+=2) {
//			sum+=i;
//		}
//		
//		System.out.println("1부터 100까지 짝수합은"+sum);
//		sum =0;
//		for(int i = 1; i<=100 ; i+=2) {
//			sum+=i;
//		}
//		System.out.println("1부터 100까지 홀수 합은"+sum);
//		sum =0;
//		for(int i = 1; i<=100 ; i++) {
//			sum+=i;
//		}
//		System.out.println("1부터 100까지합은"+sum);
//		sum = 0;
		int evsum=0,odsum=0;
		for(int i=0; i<=100; i++) {
			sum+=i;
			if(i%2==0) 
				evsum+=i;
			else
				odsum+=i;
		}
		System.out.printf("짝수합은%d 홀수합은%d 총합은%d이다",evsum,odsum,sum);
	}

}
