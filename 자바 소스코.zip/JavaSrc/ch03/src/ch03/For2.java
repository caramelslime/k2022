package ch03;

public class For2 {

	public static void main(String[] args) {
		int sum = 0;
		for(int i = 0; i<=10 ; i++) {
			sum+=i;
		}
		System.out.println("1부터 10까지합은"+sum);
	}

}
