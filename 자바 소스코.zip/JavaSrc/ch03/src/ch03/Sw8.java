package ch03;

public class Sw8 {

	public static void main(String[] args) {
		int salary = Integer.parseInt(args[0]);
		String grade = "";
		switch (salary/10) {
		case 10: grade="A";break;
		case 7: case 8: case 9: grade= "B" ; break;
		case 5: case 6: grade= "C" ; break;
		case 3: case 4: grade= "D" ; break;
		default: grade= "F"; break;
		}
		System.out.printf("월급는 %d이고 등급은%s입니다",salary,grade);
	}

}
