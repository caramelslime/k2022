package ch18;
@FunctionalInterface
interface MyFun2{
	int method(int x, int y);
}
public class LamdaReturnEx {
	public static void main(String[] args) {
		MyFun2 mf;
		mf = (x,y)-> {return x+y;};
		System.out.println(mf.method(4, 3));
	}
}
