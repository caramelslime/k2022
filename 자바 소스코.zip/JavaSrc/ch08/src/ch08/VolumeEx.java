package ch08;

class VolumeEx{
	public static void main(String[] args) {
		Tv tv= new Tv();
		Radio rd= new Radio();
		Speaker sp = new Speaker();
		tv.volumeDown();tv.volumeUp();
		rd.volumeDown();rd.volumeUp();
		sp.volumeDown();sp.volumeUp();
	}
}