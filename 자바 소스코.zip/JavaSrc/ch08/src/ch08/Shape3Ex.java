package ch08;

public class Shape3Ex {
	public static void main(String[] args) {
//		Shape3 sh3 = new Shape3(); 추상클래스는 객체생성할수없다
//		상속받는 자식 클래스를 만들고 자식클래스를 생성하여 사용, 단선언은 가능
		Shape3[] sh3 = new Shape3[3];
		sh3[0] = new Circle3();
		sh3[1] = new Triangle3();
		sh3[2] = new Rectangle3();
		
		for(Shape3 shs : sh3) {
			shs.prn();
			shs.computeArea();
		}
	}
}
