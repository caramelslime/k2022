package ch08;
class A1{
	void m1() {
		System.out.println("난 부모메서드");
	}
}
class A2 extends A1{
	void m1() {
		System.out.println("난 자식메서드");
	}
}
class A3 extends A1{
	void m1() {
		System.out.println("난 아들친구메서드");
	}
}

public class OverEx {
	public static void main(String[] args) {
		A1 a1 = new A2();//부모선언 자식생성
		a1.m1();
		A1 a3 = new A3();
		a3.m1();
	}
}
