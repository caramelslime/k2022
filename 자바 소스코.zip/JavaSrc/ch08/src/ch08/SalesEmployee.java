package ch08;

public class SalesEmployee extends Employee {
	private int annualSalary;
	public SalesEmployee(String name, int annualSalary) {
		super(name);  this.annualSalary = annualSalary;
	}
	
	public int getAnnualSalary() {		return annualSalary;	}
	public void setAnnualSalary(int annualSalary) {
		this.annualSalary = annualSalary;
	}
	@Override
	int computePay() {
		return annualSalary / 12;
	}	
//	final int computeIncentive() { // 인센티브 계산하는 식은 변경 급지
//		int result = 0;
//		int pay = computePay();
//		if (pay >= 100000) { // 급여가 10만원 이상인 경우에만 인센티브를 제공
//			double temp = pay * INCENTIVE_RATE;
//			result = (int)temp;
//		}
//		return result;
//	}
}