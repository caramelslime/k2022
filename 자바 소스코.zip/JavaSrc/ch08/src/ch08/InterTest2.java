package ch08;

interface G {
	void b1();
}
class G1 {
//	각각의 메서드는 클래스와 단단히 결합
	void m1(G f) { // 포함일 때  F2
		f.b1();
	}
}
class G2 implements G{
	public void b1() {
		System.out.println("대박");
	}
}
class G3  implements G{
	public void b1() {
		System.out.println("쪽박");
	}
}
public class InterTest2 {
	public static void main(String[] args) {
		G3 f3 = new G3();  G2 f2 = new G2();
		G1 f1 = new G1();
		f1.m1(f2);
		f1.m1(f3);
	}
}
