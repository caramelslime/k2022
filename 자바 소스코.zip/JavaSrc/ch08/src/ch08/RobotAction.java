package ch08;

public class RobotAction {
	public static void main(String[] args) {
		Robot[] r = {new DanceRobot(),new SingRobot(),new DrawRobot()};
		for(Robot rb :r) {
			action(rb);
				
		}
	}

	private static void action(Robot rb) {
		// TODO Auto-generated method stub
		if(rb instanceof DanceRobot)
			((DanceRobot) rb).dance();
		else if(rb instanceof SingRobot)
			((SingRobot) rb).Sing();
		else
			((DrawRobot)rb).Draw();
	}
}
