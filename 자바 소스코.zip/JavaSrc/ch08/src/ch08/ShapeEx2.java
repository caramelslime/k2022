package ch08;

public class ShapeEx2 {
	public static void main(String[] args) {
		Shape2[] sh = new Shape2[3];
		sh[0] = new Circle2();    // 부모를 선언 자식을 생성
		sh[1] = new Triangle2();  // up casting 묵시적
		sh[2] = new Rectangle2();
		
//		for(int i =0; i < sh.length; i++) {
//			sh[i].prn();
//		}
		String str = "hello";
		
		for(Shape2 sp:sh) {
			sp.prn();
		}
	}
}
