package ch08;
//인터페이스 클래스 대신에 interface로 사용
//모든변수는 public final 생략된 것으로 간주 변수값을 변경할수 없다
//모든 메서드는 퍼블릭 엡스트랙트가 생략된것으로 간주 선언부만있고 구현부가 없다
//인터페이스는 객체를 생성할수 없어서 구현한 클래스를 이용하여 객체를생성
interface B1 {
	int k =7;
	void m1();
	void m2();
}
//인터페이스는 익스텐드가 아니라 임플리먼츠(구현하다)를 사용한다
class B2 implements B1{

	@Override
	public void m1() {
		System.out.println("K = "+k);
		System.out.println("재택 할만하네");
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("대박사건");
	}
	
}
public class Inter1Ex {
	public static void main(String[] args) {
//		A1 a1  = new A1(); 인터페이스는 생성불가
//		A1 a1 = new A2(); 생성은안되지만 선언은가능
		B2 b2 = new B2();
		b2.m1();b2.m2();
	}
}
