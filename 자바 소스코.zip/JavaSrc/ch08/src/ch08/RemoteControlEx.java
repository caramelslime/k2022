package ch08;

public class RemoteControlEx {
	public static void main(String[] args) {
		RemoteControl[] rc = new RemoteControl[2];
		rc[0] = new Tv1Remocon();
		rc[1]= new RationRemocon();
		for(int i = 0; i<rc.length;i++) {
			rc[i].turnOn();
			rc[i].turnOff();
			rc[i].setMute(false);
			rc[i].setMute(true);
			RemoteControl.changeBattery();
			System.out.println("최대볼륨:"+RationRemocon.MAX_VOLUME);
			System.out.println("최소볼륨:"+RationRemocon.MIN_VOLUME);
		}
	}
}
