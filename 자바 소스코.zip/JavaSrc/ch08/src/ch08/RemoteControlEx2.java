package ch08;

public class RemoteControlEx2 {
	public static void main(String[] args) {
		RemoteControl rc1 = new RemoteControl() {
//			interface는 객체 생성 못함
			@Override
//			객체를 생성했다는 것은 클래스가 있는데 이름을 모름: 익명(무명){내부 중첨 inner}클래스 RemoteControllEx2$1
			public void turnOn() {
				// TODO Auto-generated method stub
				System.out.println("speaker oN");
			}
			
			@Override
			public void turnOff() {
				// TODO Auto-generated method stub
				System.out.println("speaker oFF");
			}
		};
		RemoteControl rc2 = new RemoteControl() {
//			객체를 생성했다는 것은 클래스가 있는데 이름을 모름: 익명(무명)클래스 RemoteControllEx2$2
			
			@Override
			public void turnOn() {
				// TODO Auto-generated method stub
				System.out.println("turn On the speaker");
			}
			
			@Override
			public void turnOff() {
				// TODO Auto-generated method stub
				System.out.println("turn off the speaker");
				
			}
		};
		rc1.turnOff();rc1.turnOn();rc1.setMute(false);RemoteControl.changeBattery();//인터페이스에서는 정적메서드를 객체로 실행안되는듯;;
		rc2.turnOff();rc2.turnOn();rc2.setMute(true); RemoteControl.changeBattery();
		}
}
