package ch08;
// 메서드중에 하나라도 추상메서드가 있으면 ㅎ그 클래스는 추상클래스여야 한다
// 부모클래스의 메서드중에 자식클래스 마다 다르게 실행해야 하는 메서드를 추상 메서드로 만든다.
public abstract class Shape3 {
	void prn() {
		System.out.println("자택에서 수업 들으니 편하네");
	}
	// 추상메서드는 선언부는 있으나 구현부가 없다
	abstract void computeArea();
		
}
class Circle3 extends Shape3{
	void computeArea() {
		System.out.println("원의면적 : 3.14*r*r");
	}
}
//추상메서드는 자식 클래스에서 반드시 재정의(overriding)해야한다
class Rectangle3 extends Shape3{

	@Override
	void computeArea() {
		// TODO Auto-generated method stub
		System.out.println("직사각형의면적 : 가로*세로");

	}
	
}
class Triangle3 extends Shape3{

	@Override
	void computeArea() {
		// TODO Auto-generated method stub
		System.out.println("삼각형의면적 : 밑변 *높이");

	}
lower	
}
