package ch08;

public class Shape2 {
	void prn() {
		
	}
}
class Circle2 extends Shape2{
	void prn() {
		System.out.println("원을 출력한다");
	}
}
class Triangle2 extends Shape2{
	void prn() {
		System.out.println("삼각형을 출력한다");
	}
	
}
class Rectangle2 extends Shape2{
	void prn() {
		System.out.println("직사각형을 출력한다");
	}
	
}
