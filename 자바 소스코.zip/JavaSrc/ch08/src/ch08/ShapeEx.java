package ch08;

public class ShapeEx {
	public static void main(String[] args) {
		Shape[] sh = new Shape[3];
		sh[0] = new Circle();    // 부모를 선언 자식을 생성
		sh[1] = new Triangle();  // up casting 묵시적
		sh[2] = new Rectangle();
		
		for(int i =0; i < sh.length; i++) {
			sh[i].draw();
		}
	}
}
