package ch08;

//Java 1.8(Java8)에 추가된 메서드 default, staic
public interface RemoteControl {
//	interface에 있는 모든 변수는 public final생략 
	int MAX_VOLUME = 10;  // 상수, 즉 변경하지 못함
	int MIN_VOLUME = 0;
	
//	interface 모든 메서드는 public abstract 
	void turnOff();
	void turnOn();
	
//	default 메서드는 구현부를 만들수 있다
	default void setMute(boolean mute) {
		if (mute) System.out.println("무음처리 합니다");
		else System.out.println("무음 해제 합니다");
	}
	
//	static메서드도 구현부를 만들수 있다
	static void changeBattery() {
		System.out.println("건전지를 교환합니다");
	}
}