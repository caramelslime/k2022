package ch08;

public class Robot {

}
class DanceRobot extends Robot{
	void dance() {
		System.out.println("춤을 춥니다");
	}
}
class SingRobot extends Robot{
	void Sing() {
		System.out.println("노래를 부릅니다");
	}
}
class DrawRobot extends Robot{
	void Draw() {
		System.out.println("그림을 그려요");
	}
}
