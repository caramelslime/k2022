package ch08;
//볼륨업과볼륨다운을 다양하게 사용 :다형성
public interface Volume {
	void volumeUp();
	void volumeDown();
}
class Tv implements Volume{

	@Override
	public void volumeUp() {
		// TODO Auto-generated method stub
		System.out.println("티비볼륨을 올려요");
	}

	@Override
	public void volumeDown() {
		// TODO Auto-generated method stub
		System.out.println("티비볼륨을 내려요");
	}
	
}
class Radio implements Volume{
	
	@Override
	public void volumeUp() {
		// TODO Auto-generated method stub
		System.out.println("라디오볼륨을 올려요");
	}
	
	@Override
	public void volumeDown() {
		// TODO Auto-generated method stub
		System.out.println("라디오볼륨을 내려요");
	}
	
}
class Speaker implements Volume{
	
	@Override
	public void volumeUp() {
		// TODO Auto-generated method stub
		System.out.println("스피커볼륨을 올려요");
	}
	
	@Override
	public void volumeDown() {
		// TODO Auto-generated method stub
		System.out.println("스피커볼륨을 내려요");
	}
	
}
