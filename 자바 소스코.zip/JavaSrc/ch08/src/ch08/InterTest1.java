package ch08;

class F1 {
	void m1(F2 f) { // 포함일 때
		f.b1();
	}
	void m2(F3 f) { // 포함일 때
		f.b1();
	}
}
class F2 {
	void b1() {
		System.out.println("대박");
	}
}
class F3 {
	void b1() {
		System.out.println("쪽박");
	}
}
public class InterTest1 {
	public static void main(String[] args) {
		F3 f3 = new F3(); 	F2 f2 = new F2();
		F1 f1 = new F1();
//		f1.m1(f1);
		f1.m1(f2);
		f1.m2(f3);
	}
}
