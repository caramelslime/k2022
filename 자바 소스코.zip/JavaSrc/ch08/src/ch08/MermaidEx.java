package ch08;
interface Person{
	int leg = 2 ;
	void mv();
}
interface Fish{
	void swim();
}
interface Bird{
	void eat();
}
class Mermaid implements Person,Fish,Bird{

	@Override
	public void swim()  {
		System.out.println("지느러미로 수영한다");
	}

	@Override
	public void mv()  {
		System.out.println("두 다리로 걷는다");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("부리로쪼아먹는다");
	}
	
}
public class MermaidEx {
	public static void main(String[] args) {
		Mermaid me= new Mermaid();
		me.mv();me.swim();me.eat();
		System.out.println("다리갯수:"+me.leg);
	}
}
