package ch08;
/**
 * author:kim hyunseo
 * Date:2022.7.13
 * Content: Emplyee basic 
 *
 */
public abstract class Employee {
	final double INCENTIVE_RATE = 0.1; 
	private String name;
	public Employee() {	}
	public Employee(String name) {
		this.name = name;
	}
	
	public String getName() { 	return name;	}
	public void setName(String name) {		this.name = name;	}

	abstract int computePay() ;
	
	final int computeIncentive() { 
		int result = 0;
		int pay = computePay();
		if (pay >= 100000) { 
			double temp = pay * INCENTIVE_RATE;
			result = (int)temp;
		}
		return result;
	}
}
